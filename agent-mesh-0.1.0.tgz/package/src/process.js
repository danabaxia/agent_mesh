import { spawn, execFile } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import { join, isAbsolute, extname, dirname } from 'node:path';

/**
 * Resolve a command to a directly-spawnable target for the current platform,
 * WITHOUT a shell — so the large `-p <prompt>` / `--mcp-config <path>` args never
 * face cmd.exe quoting. Handles:
 *   - *.js / *.mjs / *.cjs  → run via the current node (process.execPath). This
 *     covers the test fake-claude and any node-script bin on every platform.
 *   - win32 bare `claude`   → modern Node refuses to spawn a `.cmd`/`.bat` without
 *     a shell (CVE-2024-27980), and the real binary lives in a nested npm dir not
 *     on PATH. We find the npm `.cmd` shim on PATH and follow it to the wrapped
 *     `.exe` (or `.js`), which IS directly spawnable.
 * Returns { cmd, args, shell }.
 */
export function resolveSpawnTarget(command, args) {
  if (/\.(c|m)?js$/i.test(command)) {
    return { cmd: process.execPath, args: [command, ...args], shell: false };
  }
  if (process.platform !== 'win32') return { cmd: command, args, shell: false };
  // A concrete path or an explicit extension → spawn it (or node it) directly.
  if (isAbsolute(command) || command.includes('\\') || command.includes('/') || extname(command)) {
    return resolveConcreteWin(command, args);
  }
  // Bare command: search PATH. Prefer a real .exe, else follow a .cmd shim.
  const dirs = (process.env.PATH || process.env.Path || '').split(';').filter(Boolean);
  for (const d of dirs) {
    const exe = join(d, command + '.exe');
    if (existsSync(exe)) return { cmd: exe, args, shell: false };
  }
  for (const d of dirs) {
    const cmdShim = join(d, command + '.cmd');
    if (existsSync(cmdShim)) {
      const target = parseNpmCmdShim(cmdShim);
      if (target) return resolveConcreteWin(target, args);
      return { cmd: cmdShim, args, shell: true }; // last resort (rare)
    }
  }
  return { cmd: command, args, shell: false };
}

function resolveConcreteWin(target, args) {
  if (/\.(c|m)?js$/i.test(target)) {
    return { cmd: process.execPath, args: [target, ...args], shell: false };
  }
  return { cmd: target, args, shell: false };
}

// npm `.cmd` shims invoke e.g.  "%dp0%\node_modules\...\bin\claude.exe"  %*
// (or `node "%dp0%\..\cli.js"`). Extract that wrapped .exe/.js path, resolving
// %dp0% / %~dp0 to the shim's own directory.
function parseNpmCmdShim(cmdPath) {
  let text;
  try { text = readFileSync(cmdPath, 'utf8'); } catch { return null; }
  const dir = dirname(cmdPath);
  const m = text.match(/"%~?dp0%\\?([^"]+\.(?:exe|c?js|mjs))"/i);
  if (m) return join(dir, m[1]);
  return null;
}

export function spawnFile(command, args, options = {}) {
  return new Promise((resolve) => {
    const t = resolveSpawnTarget(command, args);
    const cmd = t.cmd;
    const cmdArgs = t.args;
    const child = spawn(cmd, cmdArgs, {
      cwd: options.cwd,
      env: options.env,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: Boolean(options.detached),
      shell: t.shell,
      windowsHide: true
    });

    let stdout = '';
    let stderr = '';
    let settled = false;
    let timedOut = false;
    let backstop = null;

    const finish = (result) => {
      if (settled) return;
      settled = true;
      if (timeout) clearTimeout(timeout);
      if (backstop) clearTimeout(backstop);
      resolve(result);
    };

    const timeout = options.timeoutMs
      ? setTimeout(() => {
          if (settled) return;
          timedOut = true;
          killProcessTree(child);
          // Do NOT resolve yet: the serialization lock is released when this
          // promise settles, so we must hold it until the worker TREE is
          // actually dead — otherwise a still-alive (acceptEdits) worker can
          // keep writing the folder while the next `do` task spawns. The
          // 'close' handler below resolves once the tree exits (SIGKILL
          // escalation in killProcessTree guarantees it does). The backstop is
          // a last resort for a truly unkillable process, so we never hang.
          backstop = setTimeout(() => {
            finish({ code: null, signal: 'SIGKILL', stdout, stderr, timedOut: true });
          }, KILL_ESCALATION_MS + 3_000);
          backstop.unref?.();
        }, options.timeoutMs)
      : null;

    child.stdout.setEncoding('utf8');
    child.stderr.setEncoding('utf8');
    child.stdout.on('data', (chunk) => {
      stdout += chunk;
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk;
    });
    child.on('error', (error) => {
      finish({ code: null, signal: null, stdout, stderr: `${stderr}${error.message}`, error });
    });
    child.on('close', (code, signal) => {
      finish({ code, signal, stdout, stderr, timedOut });
    });
  });
}

// Default grace before escalating SIGTERM → SIGKILL on a process tree that
// refuses to exit. Overridable mainly so tests can keep it short.
export const KILL_ESCALATION_MS = 2_000;

export function killProcessTree(child, escalationMs = KILL_ESCALATION_MS) {
  if (!child.pid) return;
  if (process.platform === 'win32') {
    // On Windows, process groups / signals are not available. Use taskkill to
    // recursively terminate the process tree (/T) unconditionally (/F).
    // execFile is async — its failure (e.g. taskkill missing → ENOENT) arrives as
    // an 'error' EVENT, which becomes an uncaughtException (process crash) if
    // unhandled. Attach a handler that falls back to a direct SIGKILL.
    const tk = execFile('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true });
    tk.on('error', () => { try { child.kill('SIGKILL'); } catch { /* already gone */ } });
    return;
  }
  signalTree(child, 'SIGTERM');
  // Any group member that traps/ignores SIGTERM — including a grandchild that
  // outlives the group leader — would otherwise survive the timeout and leak.
  // Follow up with an unmaskable SIGKILL to the whole group. We cannot cheaply
  // tell whether stragglers remain, so we always escalate; if the group is
  // already gone the signal is a harmless ESRCH (caught below). unref() so this
  // timer never keeps the event loop (or the test runner) alive on its own.
  const escalate = setTimeout(() => signalTree(child, 'SIGKILL'), escalationMs);
  escalate.unref?.();
}

/**
 * Kill a process tree given only a bare pid (the group leader / wrapper pid),
 * platform-aware — for cross-process takeover where we have a pid from a lease
 * file, not a ChildProcess handle. POSIX: SIGKILL the process group (`-pid`).
 * win32: `taskkill /pid <pid> /T /F` (recursive), with the async-error guard.
 */
export function killTreeByPid(pid) {
  if (!pid) return;
  if (process.platform === 'win32') {
    try {
      const tk = execFile('taskkill', ['/pid', String(pid), '/T', '/F'], { windowsHide: true });
      tk.on('error', () => { /* taskkill missing → nothing more we can do with a bare pid */ });
    } catch { /* ignore */ }
    return;
  }
  try { process.kill(-pid, 'SIGKILL'); } catch { /* already gone */ }
}

function signalTree(child, signal) {
  if (!child.pid) return;
  try {
    process.kill(-child.pid, signal);
  } catch {
    try {
      child.kill(signal);
    } catch {
      // Already gone.
    }
  }
}
