/**
 * src/dashboard/session-index.js
 * Discover + index an agent's Claude Code sessions (transcripts under
 * ~/.claude/projects/<encoded-cwd>/<uuid>.jsonl) with mesh provenance.
 */
import { readFile, writeFile, appendFile, mkdir, readdir, stat, open, realpath, unlink } from 'node:fs/promises';
import { existsSync, readdirSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, dirname, sep as PATH_SEP } from 'node:path';
import { createHash } from 'node:crypto';

const PROJECTS_DIR = join(homedir(), '.claude', 'projects');
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// ---------------------------------------------------------------------------
// Provenance event log
// ---------------------------------------------------------------------------

const hash = (s) => createHash('sha256').update(String(s)).digest('hex').slice(0, 24);
function sessionsDir(meshRoot) {
  return join(homedir(), '.agent-mesh', 'sessions', hash(meshRoot));
}
function eventsPath(meshRoot) {
  return join(sessionsDir(meshRoot), 'events.jsonl');
}
function labelsPath(meshRoot) {
  return join(sessionsDir(meshRoot), 'labels.json');
}

/** Append one management event {kind:'create'|'select'|'open', source, ...}. */
export async function recordEvent(meshRoot, ev) {
  const p = eventsPath(meshRoot);
  await mkdir(dirname(p), { recursive: true });
  const rec = { at: ev.at ?? Date.now(), ...ev };
  await appendFile(p, JSON.stringify(rec) + '\n', { mode: 0o600 });
}

export async function readEvents(meshRoot) {
  try {
    const raw = await readFile(eventsPath(meshRoot), 'utf8');
    return raw.split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { return []; }
}

/**
 * originSource = source of the session's `create` event, else 'cli'
 * (`select`/`open` never change origin); lastManagedBy = most recent event's source.
 */
export function deriveProvenance(events, sessionId) {
  const mine = events.filter((e) => e.sessionId === sessionId);
  const create = mine.find((e) => e.kind === 'create');
  const last = mine.length ? mine.reduce((a, b) => (b.at >= a.at ? b : a)) : null;
  return { originSource: create ? create.source : 'cli', lastManagedBy: last ? last.source : null };
}

// ---------------------------------------------------------------------------
// Mesh-side session LABELS (user-chosen display names). Stored separately from
// Claude Code's own transcript so renaming never touches the .jsonl. Keyed by
// session UUID under the same per-mesh provenance dir.
// ---------------------------------------------------------------------------

const MAX_LABEL_CHARS = 80;

/** Tolerant read: missing/corrupt labels file → {}. Returns { [id]: name }. */
export async function readLabels(meshRoot) {
  try {
    const raw = await readFile(labelsPath(meshRoot), 'utf8');
    const obj = JSON.parse(raw);
    if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
      const out = {};
      for (const [k, v] of Object.entries(obj)) if (typeof v === 'string') out[k] = v;
      return out;
    }
    return {};
  } catch { return {}; }
}

/**
 * Set (or, with an empty/blank name, remove) the label for a session. Validates
 * the id is a UUID; caps the name to MAX_LABEL_CHARS and strips control chars /
 * newlines so a label can't smuggle markup or break the rail row. Returns the
 * stored label (or null if removed).
 */
export async function setLabel(meshRoot, id, name) {
  if (!UUID_RE.test(id)) throw Object.assign(new Error('bad session id'), { code: 'bad_id' });
  const clean = String(name ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, MAX_LABEL_CHARS);
  const labels = await readLabels(meshRoot);
  if (clean) labels[id] = clean; else delete labels[id];
  const p = labelsPath(meshRoot);
  await mkdir(dirname(p), { recursive: true });
  await writeFile(p, JSON.stringify(labels), { mode: 0o600 });
  return clean || null;
}

/** Remove a session's label (used on delete). No-op if none. */
export async function deleteLabel(meshRoot, id) {
  return setLabel(meshRoot, id, '');
}

// ---------------------------------------------------------------------------
// Session listing + transcript resolution (Task 3)
// ---------------------------------------------------------------------------

const MAX_SCAN_BYTES = 2 * 1024 * 1024; // preview-derivation cap (NOT the cursor)
const ACTIVE_WINDOW_MS = 60_000;

// Count newlines cheaply over the WHOLE file (the cursor is never capped).
async function countLines(path) {
  const fh = await open(path, 'r');
  try {
    let count = 0; const buf = Buffer.alloc(65536); let pos = 0;
    while (true) {
      const { bytesRead } = await fh.read(buf, 0, buf.length, pos);
      if (!bytesRead) break;
      for (let i = 0; i < bytesRead; i++) if (buf[i] === 10) count++;
      pos += bytesRead;
    }
    return count;
  } finally { await fh.close(); }
}

// Preview: turns (# user_text), firstPrompt, start/end times — byte-capped.
async function derivePreview(path, parseTranscriptLine) {
  const fh = await open(path, 'r');
  try {
    const s = await fh.stat();
    const cap = Math.min(s.size, MAX_SCAN_BYTES);
    const buf = Buffer.alloc(cap);
    await fh.read(buf, 0, cap, 0);
    const lines = buf.toString('utf8').split('\n').filter(Boolean);
    let turns = 0, firstPrompt = null;
    for (const l of lines) {
      for (const ev of parseTranscriptLine(l)) {
        if (ev.type === 'user_text') { turns++; if (firstPrompt == null) firstPrompt = String(ev.text).slice(0, 200); }
      }
    }
    return { turns, firstPrompt, turnsApprox: s.size > MAX_SCAN_BYTES, startedAt: s.birthtimeMs || s.mtimeMs, endedAt: s.mtimeMs, mtimeMs: s.mtimeMs, size: s.size };
  } finally { await fh.close(); }
}

const _cache = new Map(); // path → { size, mtimeMs, preview, lineCount }

export async function listSessions(agentRoot, io = {}) {
  const { parseTranscriptLine } = await import('./session-events.js');
  const platform = io.platform || process.platform;
  const meshRoot = io.meshRoot;
  const enc = encodeProjectDir(agentRoot, platform, io);
  const projDir = join(io.projectsDir || PROJECTS_DIR, enc);
  let names = [];
  try { names = (await readdir(projDir)).filter((n) => n.endsWith('.jsonl')); } catch { return []; }
  // Read events + labels ONCE and reuse for all sessions (not per-session).
  const events = meshRoot ? await readEvents(meshRoot) : [];
  const labels = meshRoot ? await readLabels(meshRoot) : {};
  const rows = [];
  for (const name of names) {
    const id = name.replace(/\.jsonl$/, '');
    if (!UUID_RE.test(id)) continue;
    const path = join(projDir, name);
    const s = await stat(path);
    let entry = _cache.get(path);
    if (!entry || entry.size !== s.size || entry.mtimeMs !== s.mtimeMs) {
      entry = { size: s.size, mtimeMs: s.mtimeMs, preview: await derivePreview(path, parseTranscriptLine), lineCount: await countLines(path) };
      _cache.set(path, entry);
    }
    const prov = deriveProvenance(events, id);
    rows.push({
      id, transcriptPath: path, lineCount: entry.lineCount,
      turns: entry.preview.turns, firstPrompt: entry.preview.firstPrompt, turnsApprox: entry.preview.turnsApprox,
      startedAt: entry.preview.startedAt, endedAt: entry.preview.endedAt,
      active: (Date.now() - entry.preview.mtimeMs) < ACTIVE_WINDOW_MS,
      originSource: prov.originSource, lastManagedBy: prov.lastManagedBy,
      label: labels[id] ?? null
    });
  }
  rows.sort((a, b) => b.endedAt - a.endedAt);
  return rows;
}

/** UUID + index-only resolution + realpath containment under the agent's project dir. */
export async function resolveTranscript(agentRoot, id, io = {}) {
  if (!UUID_RE.test(id)) throw Object.assign(new Error('bad session id'), { code: 'bad_id' });
  const platform = io.platform || process.platform;
  const enc = encodeProjectDir(agentRoot, platform, io);
  const projDir = join(io.projectsDir || PROJECTS_DIR, enc);
  // Index-only: check the directory listing before any realpath call.
  let names;
  try { names = await readdir(projDir); } catch { throw Object.assign(new Error('unknown session'), { code: 'not_found' }); }
  if (!names.includes(`${id}.jsonl`)) throw Object.assign(new Error('unknown session'), { code: 'not_found' });
  const candidate = join(projDir, `${id}.jsonl`);
  const rp = io.realpath || realpath;
  let real;
  try { real = await rp(candidate); } catch { throw Object.assign(new Error('unknown session'), { code: 'not_found' }); }
  const realDir = await rp(projDir).catch(() => projDir);
  // Anchor the prefix with the PLATFORM separator so `-proj` can't match a sibling
  // `-projMalicious` (startsWith without a boundary is a path-prefix bypass). Using
  // a hardcoded '/' broke this on Windows, where realpath returns '\\'-separated
  // paths — every transcript was rejected with `containment` (404) and the
  // session-log board stayed empty.
  const boundary = realDir.endsWith(PATH_SEP) ? realDir : realDir + PATH_SEP;
  if (real !== realDir && !real.startsWith(boundary)) {
    throw Object.assign(new Error('path escapes project dir'), { code: 'containment' });
  }
  return real;
}

/**
 * PERMANENTLY delete a session's real transcript (~/.claude/projects/.../<id>.jsonl).
 * The path is obtained ONLY via resolveTranscript (UUID + index-membership +
 * realpath containment) — never hand-joined — so the same security gate that
 * protects read/stream protects the unlink. Resolve errors (bad_id/not_found/
 * containment) propagate; the route maps them to 4xx. The preview/lineCount
 * cache entry for the deleted path is evicted so a recreated id can't show stale
 * data. Returns { ok: true }.
 */
export async function deleteSession(agentRoot, id, io = {}) {
  const real = await resolveTranscript(agentRoot, id, io);
  await unlink(real);
  // Evict cache. listSessions keys by the index-joined path (pre-realpath); the
  // resolved real path may differ under a symlink, so evict both keys.
  _cache.delete(real);
  const enc = encodeProjectDir(agentRoot, io.platform || process.platform, io);
  _cache.delete(join(io.projectsDir || PROJECTS_DIR, enc, `${id}.jsonl`));
  return { ok: true };
}

// ---------------------------------------------------------------------------
// encodeProjectDir
// ---------------------------------------------------------------------------

/**
 * Encode a launch cwd into Claude Code's project-dir name. Claude prefixes the
 * encoded name with `-` (a leading separator), so we do too:
 *   darwin/linux: replace `/` and `.` with `-`; win32: replace `\`, `/`, `:`, `.`.
 * If the computed dir is absent, fall back to an **exact** alternate-scheme match
 * (the path's components joined by `-`, with a leading `-`) — this covers a likely
 * scheme drift (e.g. dots kept rather than dashed) while AVOIDING the partial
 * `endsWith` collisions that could return a *different* same-user project's dir
 * (e.g. `/agent` matching `-Users-me-agent`). Containment is still realpath-checked
 * downstream by `resolveTranscript`.
 */
export function encodeProjectDir(canonicalRoot, platform = process.platform, io = {}) {
  const projectsDir = io.projectsDir || PROJECTS_DIR;
  // Claude Code encodes the launch cwd by replacing EVERY non-alphanumeric
  // character with '-'. On POSIX the leading '/' yields the leading '-'; on
  // Windows the drive letter means there is NO leading '-':
  //   /Users/me/agent      → -Users-me-agent
  //   C:\AI\agents_mesh\x   → C--AI-agents-mesh-x
  // The previous scheme replaced only [\\/:.] (missing '_' and others) and
  // force-prefixed '-', so on Windows it computed a directory name that never
  // existed — listSessions/resolveTranscript then found nothing and the
  // session-log view stayed empty even though Claude had written the transcript.
  const computed = String(canonicalRoot).replace(/[^a-zA-Z0-9]/g, '-');
  try {
    if (existsSync(join(projectsDir, computed))) return computed;
    // Case-insensitive exact-match fallback for drive-letter / path-casing drift
    // (Windows paths can surface with either drive-letter case). Anchored
    // equality — never a loose suffix — so it can't pick a sibling project.
    const ci = platform === 'win32';
    for (const name of readdirSync(projectsDir)) {
      if (name === computed || (ci && name.toLowerCase() === computed.toLowerCase())) return name;
    }
  } catch { /* projectsDir may not exist yet → use computed */ }
  return computed;
}
