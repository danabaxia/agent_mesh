/**
 * src/dashboard/activity.js
 *
 * PURE transform: parsed run-log records → live board activity. The board shows
 * only STATUS / PHASE INDICATORS (working/done, route, which agent is talking to
 * which) — **never task text or result data**. The actual conversation/output
 * lives in the Desk chat window (the console's Task response), not on the board,
 * so the dashboard stays uncluttered.
 *
 * Because no free text is emitted here, there is nothing to leak: the payload is
 * structurally incapable of carrying a path, a secret, or model output (a
 * stronger guarantee than the earlier scrub-and-cap).
 *
 * Records are stamped by the runtime start-log: { agent, id, parent_run_id?,
 * route?, started_at, finished_at? }.
 */

const MAX_EVENTS = 40;

/**
 * @param {Array<object>} records  parsed run-log records (each with `agent`)
 * @returns {{ agents: object[], edges: object[], events: object[] }}
 *   agents: { name, state:'working'|'done', route, since }
 *   edges:  { from, to, active }              (deterministic parent_run_id links)
 *   events: { kind:'start'|'done', agent, route, at }   (phase indicators only)
 */
export function buildActivity(records) {
  const list = Array.isArray(records) ? records.filter((r) => r && r.agent) : [];

  // Latest record per agent → state (status only, no text).
  const byAgent = new Map();
  for (const r of list) {
    const t = ts(r.started_at);
    const prev = byAgent.get(r.agent);
    if (!prev || t >= prev._t) byAgent.set(r.agent, { ...r, _t: t });
  }
  const agents = [...byAgent.values()].map((r) => ({
    name: r.agent,
    state: r.finished_at ? 'done' : 'working',
    route: r.route || null,
    since: r.started_at || null
  }));

  // Deterministic edges: parent_run_id → child id (which agent is delegating to
  // which). Active = child still running. No conversation text on the board.
  const byId = new Map(list.filter((r) => r.id).map((r) => [r.id, r]));
  const edges = [];
  for (const r of list) {
    if (!r.parent_run_id) continue;
    const parent = byId.get(r.parent_run_id);
    if (!parent || parent.agent === r.agent) continue;
    edges.push({ from: parent.agent, to: r.agent, active: !r.finished_at });
  }

  // Bounded, time-ordered phase feed (start/done + route). No text content.
  const events = list
    .slice()
    .sort((a, b) => ts(a.started_at) - ts(b.started_at))
    .slice(-MAX_EVENTS)
    .map((r) => ({
      kind: r.finished_at ? 'done' : 'start',
      agent: r.agent,
      route: r.route || null,
      at: r.finished_at || r.started_at || null
    }));

  return { agents, edges, events };
}

function ts(s) {
  const t = Date.parse(s || '');
  return Number.isFinite(t) ? t : 0;
}
