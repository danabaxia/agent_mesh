/**
 * src/dashboard/public/session-log.js — B-layout, one-session-per-agent.
 *
 * Layout:
 *   ┌ toolbar: sid · ⧉ id · ⌘ Terminal ································ Session | Activity | Worklog
 *   ├ board (chat, polished cards) ───────────────── overlay: User · Reply · Tool · ⛶
 *   ├ side panel: Session  (meta summary + transcript outline + rename/copy/delete)
 *   ├ side panel: Activity (process events stream — unchanged from before)
 *   ├ side panel: Worklog  (WORK_LOG.md per agent)
 *   └ compose
 *
 * The rail's session-LIST is gone — each agent reuses a single canonical
 * session; we just open sessions[0] from /session/list. Tools now appear as
 * cards in the chat board AND as compact events in Activity (render-core's
 * 'both' channel). The transcript outline in Session is derived from rendered
 * blocks (data-seq) and jumps the board to the matching card on click.
 */
import { createResultCanvas } from './result-canvas.js';

export function mountSessionLog(rootEl, agentName) {
  rootEl.classList.add('sl-root');
  rootEl.innerHTML = `
    <div class="sl-bar">
      <span id="sl-sid" class="sl-sid" title="active session id">—</span>
      <button id="sl-copyid" class="sl-btn" title="Copy session id">⧉ id</button>
      <button id="sl-term" class="sl-btn sl-amber" title="Open this session in Claude CLI (claude --resume)">⌘ Terminal — open in Claude CLI</button>
      <span class="sl-spacer"></span>
      <button id="sl-tog-session"  class="sl-btn on" data-tog="session"  title="Show/hide the Session panel">⊟ Session</button>
      <button id="sl-tog-activity" class="sl-btn on" data-tog="activity" title="Show/hide the Activity panel">⚙ Activity</button>
      <button id="sl-tog-worklog"  class="sl-btn on" data-tog="worklog"  title="Show/hide the Work log panel">✎ Work log</button>
    </div>

    <div class="sl-canvas" id="sl-canvas">

      <div class="sl-board-frame">
        <div class="sl-overlay-tr">
          <div class="sl-filters" role="group" aria-label="Hide card types">
            <button class="sl-filter on" data-fil="you"  title="Hide user prompts">💬 User</button>
            <button class="sl-filter on" data-fil="text" title="Hide Claude replies">✦ Reply</button>
            <button class="sl-filter on" data-fil="tool" title="Hide tool cards">⚙ Tool</button>
          </div>
          <button id="sl-full" class="sl-fullbtn" title="Presentation view (full chat)">⛶</button>
        </div>
        <div class="sl-board" id="sl-board"></div>
      </div>

      <aside class="sl-side sl-session" id="sl-session">
        <div class="sl-side-head">
          <div class="sl-side-title"><span>Session</span><span id="sl-session-pill" class="sl-pill"></span></div>
          <button class="sl-side-x" data-tog="session" title="Collapse">›</button>
        </div>
        <div class="sl-side-body">
          <div class="sm" id="sl-session-meta"><div class="sl-empty">Loading…</div></div>
          <div class="sm-outline-head">
            <span>Transcript</span>
            <span class="sm-outline-count" id="sl-outline-count">0 turns</span>
          </div>
          <div class="sm-outline" id="sl-outline"></div>
          <div class="sm-actions">
            <button id="sl-rename"   class="sl-btn" title="Rename this session">✎ Rename</button>
            <button id="sl-copymeta" class="sl-btn" title="Copy session meta">📋 Copy meta</button>
            <button id="sl-delete"   class="sl-btn" title="Permanently delete this session transcript">🗑 Delete</button>
          </div>
        </div>
      </aside>

      <aside class="sl-side sl-activity" id="sl-activity">
        <div class="sl-side-head">
          <div class="sl-side-title"><span>Activity</span></div>
          <button class="sl-side-x" data-tog="activity" title="Collapse">›</button>
        </div>
        <div class="sl-side-body" id="sl-activity-body"></div>
      </aside>

      <aside class="sl-side sl-worklog" id="sl-worklog">
        <div class="sl-side-head">
          <div class="sl-side-title"><span>Work log</span><span class="sl-pill">WORK_LOG.md</span></div>
          <button class="sl-side-x" data-tog="worklog" title="Collapse">›</button>
        </div>
        <div class="sl-side-body" id="sl-worklog-body"><div class="sl-empty">Loading…</div></div>
      </aside>

    </div>`;
    // No inline compose — the dashboard chat composer above (#composer in app.js
    // via wireConsole) already POSTs to /session/message, and ⌘ Terminal is the
    // canonical entry point into the Claude CLI for free-form interaction.

  const boardEl        = rootEl.querySelector('#sl-board');
  const activityBodyEl = rootEl.querySelector('#sl-activity-body');
  const sidEl          = rootEl.querySelector('#sl-sid');
  const sessPillEl     = rootEl.querySelector('#sl-session-pill');
  const sessMetaEl     = rootEl.querySelector('#sl-session-meta');
  const outlineEl      = rootEl.querySelector('#sl-outline');
  const outlineCountEl = rootEl.querySelector('#sl-outline-count');
  const worklogBodyEl  = rootEl.querySelector('#sl-worklog-body');

  const canvas = createResultCanvas(boardEl, activityBodyEl);

  // openId = the session whose transcript is currently shown. (No activeId /
  // expectedActiveId tracking — the outer chat composer owns send semantics.)
  let openId = null;
  let openSessionMeta = null;
  let stream = null;
  let oldestSeq = null, loadingOlder = false, exhausted = false;
  let destroyed = false;

  const api = (p, o) =>
    fetch(`/api/agent/${encodeURIComponent(agentName)}${p}`, { credentials: 'same-origin', ...o });
  const jsonHeaders = { 'Content-Type': 'application/json' };

  // ── panel collapse: 3 panels, independent state ──────────────────────────
  function togglePanel(name) {
    const cls = `sl-${name}-collapsed`;
    const collapsed = rootEl.classList.toggle(cls);
    const btn = rootEl.querySelector(`#sl-tog-${name}`);
    if (btn) btn.classList.toggle('on', !collapsed);
  }
  for (const el of rootEl.querySelectorAll('[data-tog]')) {
    el.addEventListener('click', () => togglePanel(el.dataset.tog));
  }

  // ── chat filter chips ────────────────────────────────────────────────────
  // Each chip toggles `hide-<kind>` on .sl-board; CSS hides matching .rc-<kind>.
  for (const chip of rootEl.querySelectorAll('[data-fil]')) {
    chip.addEventListener('click', () => {
      const k = chip.dataset.fil;
      const hidden = boardEl.classList.toggle(`hide-${k}`);
      chip.classList.toggle('on', !hidden);
    });
  }

  // ── one canonical session per agent ──────────────────────────────────────
  // /session/list is newest-first; we pin sessions[0]. Auto-refreshes every 4s
  // so a fresh `claude --resume` started in iTerm surfaces here promptly.
  async function loadCanonicalSession() {
    let j;
    try { j = await (await api('/session/list')).json(); } catch { j = { sessions: [] }; }
    if (destroyed) return;
    const sessions = j.sessions || [];
    if (!sessions.length) {
      renderEmptySession();
      return;
    }
    const primary = sessions[0];
    openSessionMeta = primary;
    renderSessionMeta(primary);
    if (primary.id !== openId) {
      await openSession(primary.id);
    }
  }

  function renderEmptySession() {
    sidEl.textContent = '—'; sidEl.title = '';
    sessPillEl.textContent = '';
    sessMetaEl.innerHTML = '<div class="sl-empty">No session yet. Use <b>⌘ Terminal</b> to start <code>claude</code> in this agent\'s folder; it will surface here within a few seconds.</div>';
    outlineEl.innerHTML = '';
    outlineCountEl.textContent = '0 turns';
    if (openId) {
      if (stream) { stream.close(); stream = null; }
      canvas.clear();
      openId = null;
    }
  }

  function renderSessionMeta(s) {
    const shortId = s.id ? s.id.slice(0, 8) : '—';
    sidEl.textContent = shortId + (s.label || s.firstPrompt ? ' · ' + truncate(s.label || s.firstPrompt, 36) : '');
    sidEl.title = s.id || '';
    sessPillEl.textContent = s.originSource === 'cli' ? '⌘ CLI' : '💬 dash';
    const turns = (s.turns ?? 0) + (s.turnsApprox ? '+' : '');
    const rows = [
      ['id',         s.id || '—'],
      ['origin',     s.originSource || 'cli'],
      ['started',    fmtTime(s.startedAt)],
      ['last',       fmtTime(s.endedAt || s.startedAt)],
      ['turns',      String(turns)],
    ];
    if (s.label)       rows.push(['label', s.label]);
    if (s.firstPrompt) rows.push(['prompt', truncate(s.firstPrompt, 80)]);
    if (s.active)      rows.push(['status', 'live']);
    sessMetaEl.innerHTML = rows.map(([k, v]) =>
      `<div class="sm-row"><span class="sm-k">${escapeText(k)}</span><span class="sm-v ${k === 'prompt' || k === 'label' ? '' : 'muted'}">${escapeText(v)}</span></div>`
    ).join('');
  }

  // ── open the canonical session: windowed transcript + live tail ─────────
  async function openSession(id) {
    openId = id;
    canvas.clear();
    outlineEl.innerHTML = '';
    outlineCountEl.textContent = '0 turns';
    oldestSeq = null; exhausted = false; loadingOlder = false;
    if (stream) { stream.close(); stream = null; }

    let t;
    try { t = await (await api(`/session/${id}/transcript`)).json(); } catch { t = { records: [] }; }
    if (destroyed || openId !== id) return;
    const records = t.records || [];
    canvas.renderAll(records);
    rebuildOutline();
    if (records.length) oldestSeq = records[0].seq;
    exhausted = !t.hasMore;

    if (typeof EventSource !== 'undefined') {
      // Past→live handoff via ?fromSeq so the mirror starts exactly after the
      // last rendered seq (no overlap, no replay_gap loop).
      const newestSeq = records.length ? records[records.length - 1].seq : 0;
      stream = new EventSource(streamUrl(agentName, id, newestSeq));
      stream.addEventListener('record', (e) => {
        try {
          const rec = JSON.parse(e.data);
          canvas.render(rec);
          appendOutlineFor(rec);
        } catch { /* ignore malformed */ }
      });
      stream.addEventListener('gap', () => openSession(id));
      stream.addEventListener('error', () => { if (openId === id) flash('Live stream disconnected — reconnecting…'); });
    }
  }

  // Reverse-pagination: scroll-to-top fetches the window before the oldest seq.
  async function loadOlder() {
    if (loadingOlder || exhausted || openId == null || oldestSeq == null) return;
    loadingOlder = true;
    const before = oldestSeq;
    let t;
    try { t = await (await api(`/session/${openId}/transcript?beforeSeq=${before}`)).json(); }
    catch { t = { records: [] }; }
    if (destroyed) { loadingOlder = false; return; }
    const older = t.records || [];
    if (older.length) {
      const prevH = boardEl.scrollHeight;
      canvas.prepend(older);
      boardEl.scrollTop += boardEl.scrollHeight - prevH;
      oldestSeq = older[0].seq;
      prependOutlineFor(older);
    }
    exhausted = !t.hasMore;
    loadingOlder = false;
  }
  boardEl.addEventListener('scroll', () => { if (boardEl.scrollTop < 40) loadOlder(); });

  // ── transcript outline (derived from rendered .rc-blk[data-seq] in board) ─
  // The board is the source of truth — outline scans new blocks after each
  // render and reuses jumpTo() to scroll + flash on click. Tools are in both
  // lanes (render-core 'both'), but we list the board copy only.
  function rebuildOutline() {
    outlineEl.innerHTML = '';
    const blks = boardEl.querySelectorAll('.rc-blk[data-seq]');
    for (const b of blks) outlineEl.appendChild(outlineRowFor(b));
    outlineCountEl.textContent = `${blks.length} turns shown`;
  }
  function appendOutlineFor(/* rec */) {
    // Find the new block(s) at the tail that aren't yet in the outline.
    const blks = boardEl.querySelectorAll('.rc-blk[data-seq]:not([data-outlined])');
    for (const b of blks) outlineEl.appendChild(outlineRowFor(b));
    outlineCountEl.textContent = `${boardEl.querySelectorAll('.rc-blk[data-seq]').length} turns shown`;
  }
  function prependOutlineFor(/* recs */) {
    // Walk new blocks at the head and prepend their rows in document order.
    const blks = Array.from(boardEl.querySelectorAll('.rc-blk[data-seq]:not([data-outlined])'));
    for (let i = blks.length - 1; i >= 0; i--) outlineEl.insertBefore(outlineRowFor(blks[i]), outlineEl.firstChild);
    outlineCountEl.textContent = `${boardEl.querySelectorAll('.rc-blk[data-seq]').length} turns shown`;
  }
  function outlineRowFor(blk) {
    blk.setAttribute('data-outlined', '1');
    const seq = blk.dataset.seq || '0';
    const kind = inferKind(blk);
    const preview = truncate((blk.innerText || '').replace(/\s+/g, ' ').trim().replace(/^⧉\s*/, ''), 80);
    const row = document.createElement('div');
    row.className = 'ol';
    row.dataset.jump = seq + ':' + blk.dataset.seqIndex;
    row.innerHTML =
      `<span class="ol-t">#${escapeText(seq)}</span>` +
      `<span class="ol-r r-${escapeText(kind)}">${escapeText(kindLabel(kind))}</span>` +
      `<span class="ol-x">${escapeText(preview || '(empty)')}</span>`;
    row.addEventListener('click', () => jumpTo(blk));
    return row;
  }
  function inferKind(blk) {
    for (const c of blk.classList) {
      if (c === 'rc-blk') continue;
      if (c.startsWith('rc-')) return c.slice(3);
    }
    return 'raw';
  }
  function kindLabel(kind) {
    return ({ you: 'user', text: 'reply', tool: 'tool', result: 'result', raw: 'raw' })[kind] || kind;
  }
  function jumpTo(blk) {
    blk.scrollIntoView({ behavior: 'smooth', block: 'center' });
    blk.classList.remove('flash');
    void blk.offsetWidth;            // restart animation
    blk.classList.add('flash');
  }

  // ── work log (per-agent WORK_LOG.md, read-only for v1) ───────────────────
  async function loadWorklog() {
    let j;
    try { j = await (await api('/worklog')).json(); } catch { j = { exists: false }; }
    if (destroyed) return;
    if (!j || j.exists === false || !String(j.content || '').trim()) {
      worklogBodyEl.innerHTML = `<div class="sl-empty">No <code>WORK_LOG.md</code> in this agent's folder yet. Create one to capture decisions / blockers / next steps for the long-running maintainer.</div>`;
      return;
    }
    // Minimal markdown: headings + bullets + paragraphs. Safe via textContent
    // assignment per fragment; no raw HTML passthrough.
    worklogBodyEl.innerHTML = `<div class="worklog">${renderTinyMd(j.content)}</div>`;
  }

  // ── toolbar actions ──────────────────────────────────────────────────────
  rootEl.querySelector('#sl-copyid').onclick = async () => {
    if (!openId) return;
    const btn = rootEl.querySelector('#sl-copyid');
    try { await navigator.clipboard.writeText(openId); btn.textContent = '✓ id'; }
    catch { btn.textContent = '⚠ id'; }
    setTimeout(() => { btn.textContent = '⧉ id'; }, 1200);
  };
  rootEl.querySelector('#sl-term').onclick = async () => {
    if (!openId) return;
    try {
      const j = await (await api(`/session/${openId}/open-terminal`, { method: 'POST', headers: jsonHeaders, body: '{}' })).json();
      if (!j.ok) { flash('Open terminal failed: ' + (j.error?.code || 'error')); return; }
      // Server now chains buildPlan → launch; the OS terminal opens directly.
      // Just confirm via a flash; no alert with command to copy.
      flash(j.opened ? 'Opening Claude CLI in terminal…' : 'Terminal launcher returned no opener — check `claude` is on PATH');
    } catch (e) { flash('Open terminal failed: ' + e.message); }
  };
  rootEl.querySelector('#sl-full').onclick = () => {
    const on = rootEl.classList.toggle('sl-presentation');
    canvas.setMode(on ? 'presentation' : 'inline');
  };

  // Per-session actions (Session panel footer): rename / copy meta / delete
  rootEl.querySelector('#sl-rename').onclick = async () => {
    if (!openSessionMeta) return;
    const s = openSessionMeta;
    const name = prompt('Rename session', s.label || s.firstPrompt || '');
    if (name == null) return;
    try {
      const r = await api(`/session/${s.id}/rename`, { method: 'POST', headers: jsonHeaders, body: JSON.stringify({ name }) });
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.ok) loadCanonicalSession();
      else flash('Rename failed: ' + (j.error?.code || r.status));
    } catch (e) { flash('Rename failed: ' + e.message); }
  };
  rootEl.querySelector('#sl-copymeta').onclick = async () => {
    if (!openSessionMeta) return;
    const s = openSessionMeta;
    const md = [
      `# Session ${s.id || ''}`,
      `- origin: ${s.originSource || 'cli'}`,
      `- started: ${fmtTime(s.startedAt)}`,
      `- last: ${fmtTime(s.endedAt || s.startedAt)}`,
      `- turns: ${s.turns ?? 0}${s.turnsApprox ? '+' : ''}`,
      s.label       ? `- label: ${s.label}` : null,
      s.firstPrompt ? `- first prompt: ${s.firstPrompt}` : null
    ].filter(Boolean).join('\n');
    try { await navigator.clipboard.writeText(md); flash('Meta copied'); }
    catch { flash('Copy blocked by browser'); }
  };
  rootEl.querySelector('#sl-delete').onclick = async () => {
    if (!openSessionMeta) return;
    const s = openSessionMeta;
    if (!confirm('Permanently delete this session transcript?\n\nThis removes Claude Code\'s OWN history for this session (~/.claude/projects) and cannot be undone.')) return;
    try {
      const r = await api(`/session/${s.id}/delete`, { method: 'POST', headers: jsonHeaders, body: '{}' });
      const j = await r.json().catch(() => ({}));
      if (r.ok && j.ok) {
        if (stream) { stream.close(); stream = null; }
        canvas.clear();
        openId = null; openSessionMeta = null;
        loadCanonicalSession();
      } else flash('Delete failed: ' + (j.error?.code || r.status));
    } catch (e) { flash('Delete failed: ' + e.message); }
  };

  // ── ephemeral status toast ───────────────────────────────────────────────
  let flashTimer = null;
  function flash(msg) {
    let el = rootEl.querySelector('.sl-flash');
    if (!el) { el = document.createElement('div'); el.className = 'sl-flash'; rootEl.appendChild(el); }
    el.textContent = msg; el.classList.add('on');
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => el.classList.remove('on'), 2600);
  }

  // ── kickoff + refresh ────────────────────────────────────────────────────
  loadCanonicalSession();
  loadWorklog();
  const refreshTimer = setInterval(() => {
    if (destroyed) return;
    loadCanonicalSession();   // surfaces a fresh CLI session promptly
  }, 4000);
  const worklogTimer = setInterval(() => {
    if (destroyed) return;
    loadWorklog();            // pick up manual edits to WORK_LOG.md
  }, 8000);

  return {
    destroy() {
      destroyed = true;
      if (stream) { stream.close(); stream = null; }
      clearInterval(refreshTimer);
      clearInterval(worklogTimer);
      clearTimeout(flashTimer);
      canvas.destroy();
      rootEl.innerHTML = '';
      rootEl.classList.remove('sl-root', 'sl-presentation');
    }
  };
}

// ── helpers ─────────────────────────────────────────────────────────────────

/**
 * Build the live-mirror EventSource URL, threading the transcript cursor as the
 * initial resume point. Exported so the past→live handoff is unit-testable.
 */
export function streamUrl(agentName, id, fromSeq) {
  const seq = Math.max(0, Math.floor(Number(fromSeq) || 0));
  return `/api/agent/${encodeURIComponent(agentName)}/session/${encodeURIComponent(id)}/stream?fromSeq=${seq}`;
}

function escapeText(s) {
  const d = document.createElement('div');
  d.textContent = String(s == null ? '' : s);
  return d.innerHTML;
}

function truncate(s, n) {
  s = String(s == null ? '' : s);
  return s.length > n ? s.slice(0, n - 1) + '…' : s;
}

function fmtTime(ms) {
  if (!ms) return '—';
  try { return new Date(ms).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }); }
  catch { return '—'; }
}

/**
 * Tiny safe markdown for the Work log panel: headings (#–###), bullets (-/*),
 * paragraphs, inline `code` and **bold**. Everything is escaped first; no raw
 * HTML passthrough.
 */
function renderTinyMd(src) {
  const lines = String(src || '').split(/\r?\n/);
  const out = [];
  let inUl = false;
  const flushUl = () => { if (inUl) { out.push('</ul>'); inUl = false; } };
  for (const ln of lines) {
    if (/^\s*$/.test(ln)) { flushUl(); continue; }
    const h = /^(#{1,3})\s+(.+?)\s*$/.exec(ln);
    if (h) { flushUl(); const n = h[1].length; out.push(`<h${n} class="wl-h${n}">${inline(h[2])}</h${n}>`); continue; }
    const li = /^\s*[-*]\s+(.+?)\s*$/.exec(ln);
    if (li) { if (!inUl) { out.push('<ul>'); inUl = true; } out.push(`<li>${inline(li[1])}</li>`); continue; }
    flushUl(); out.push(`<p>${inline(ln)}</p>`);
  }
  flushUl();
  return out.join('');
  function inline(s) {
    return escapeText(s)
      .replace(/`([^`]+)`/g, (_, c) => `<code>${c}</code>`)
      .replace(/\*\*([^*]+)\*\*/g, (_, c) => `<b>${c}</b>`);
  }
}

// app.js is a classic script and can't `import`; expose the mount on window so
// it can call it. Loaded via <script type="module" src="/session-log.js">.
if (typeof window !== 'undefined') window.mountSessionLog = mountSessionLog;
