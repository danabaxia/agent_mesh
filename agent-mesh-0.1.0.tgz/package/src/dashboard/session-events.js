/**
 * src/dashboard/session-events.js — PURE.
 * Normalize `claude --output-format stream-json` NDJSON lines into dashboard
 * events, and scrub/cap every rendered string field before it reaches the
 * browser. Tolerant: unknown/malformed → a `raw` event, never throws.
 * Trust model: defense-in-depth on an operator-owned localhost session, not a
 * hard boundary (spec §7).
 */

const MAX_FIELD_CHARS = 20_000;
const MAX_FIELD_LINES = 400;

// Secret-shaped substrings → replaced with «redacted». Conservative, additive.
const SECRET_PATTERNS = [
  /sk-[A-Za-z0-9_-]{4,}/g,                  // OpenAI-style (and similar sk- prefixed keys)
  /ghp_[A-Za-z0-9]{20,}/g,                  // GitHub PAT
  /AKIA[0-9A-Z]{16}/g,                      // AWS access key id
  /xox[baprs]-[A-Za-z0-9-]{10,}/g,          // Slack
  /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g,
  /\b[A-Fa-f0-9]{32,}\b/g,                  // long hex secrets/tokens
  /\b[A-Za-z0-9_-]{16,}=[A-Za-z0-9/+_-]{12,}/g // KEY=secretish-value
];

function scrubString(s) {
  let out = String(s);
  for (const re of SECRET_PATTERNS) out = out.replace(re, '«redacted»');
  return out;
}

function capString(s) {
  let str = String(s);
  if (str.length > MAX_FIELD_CHARS) {
    const head = str.slice(0, MAX_FIELD_CHARS);
    str = `${head}\n… ${str.length - MAX_FIELD_CHARS} more chars`;
  }
  const lines = str.split('\n');
  if (lines.length > MAX_FIELD_LINES) {
    str = lines.slice(0, MAX_FIELD_LINES).join('\n') + `\n… ${lines.length - MAX_FIELD_LINES} more lines`;
  }
  return str;
}

// Recurse over every string in a value, applying scrub + cap. Objects/arrays
// rebuilt; non-strings passed through. A depth guard prevents a pathologically
// nested payload (JSON.parse imposes no depth limit) from overflowing the stack
// and crashing the dashboard process. Scrub BEFORE cap so a secret straddling
// the cap boundary cannot leave an un-scrubbed prefix in the rendered head.
const MAX_REDACT_DEPTH = 100;
function redactValue(v, depth = 0) {
  if (typeof v === 'string') return capString(scrubString(v));
  if (depth > MAX_REDACT_DEPTH) return '[redacted: too deep]';
  if (Array.isArray(v)) return v.map((x) => redactValue(x, depth + 1));
  if (v && typeof v === 'object') {
    const out = {};
    for (const [k, val] of Object.entries(v)) out[k] = redactValue(val, depth + 1);
    return out;
  }
  return v;
}

/** @returns {Array<object>} normalized events (possibly several per line) */
export function parseEventLine(line) {
  let msg;
  try { msg = JSON.parse(line); } catch { return [{ type: 'raw', raw: String(line) }]; }
  try {
    if (msg.type === 'system' && msg.subtype === 'init') {
      return [{ type: 'init', sessionId: msg.session_id, model: msg.model, cwd: msg.cwd }];
    }
    if (msg.type === 'assistant' && msg.message?.content) {
      const out = [];
      for (const b of msg.message.content) {
        if (b.type === 'text') out.push({ type: 'text', text: b.text });
        else if (b.type === 'tool_use') out.push({ type: 'tool_use', id: b.id, name: b.name, input: b.input });
        // thinking and other block types are intentionally dropped in the MVP
      }
      return out.length ? out : [{ type: 'raw', raw: line }];
    }
    if (msg.type === 'user' && msg.message?.content) {
      const out = [];
      for (const b of msg.message.content) {
        if (b.type === 'tool_result') out.push({ type: 'tool_result', toolUseId: b.tool_use_id, content: b.content });
      }
      return out.length ? out : [{ type: 'raw', raw: line }];
    }
    if (msg.type === 'result') {
      return [{ type: 'turn_done', result: msg.result ?? '', isError: !!msg.is_error }];
    }
    return [{ type: 'raw', raw: line }];
  } catch {
    return [{ type: 'raw', raw: String(line) }];
  }
}

/**
 * Parse one line of a Claude Code SESSION TRANSCRIPT (`~/.claude/projects/<dir>/
 * <uuid>.jsonl`) — a DIFFERENT, internal format from `-p --output-format
 * stream-json`. Transcript lines are wrapped records with types like
 * `user`/`assistant`/`system`/`mode`/`attachment`/`last-prompt`. We surface the
 * human-readable conversation: the typed prompt (`user_text`), assistant text /
 * tool calls, and tool results. Everything else → ignored (empty array).
 * Tolerant: malformed → `raw`, never throws.
 * @returns {Array<object>}
 */
export function parseTranscriptLine(line) {
  let msg;
  try { msg = JSON.parse(line); } catch { return [{ type: 'raw', raw: String(line) }]; }
  try {
    const content = msg.message?.content;
    if (msg.type === 'user') {
      // A plain string is the human's typed prompt; an array carries tool_results.
      if (typeof content === 'string') return content.trim() ? [{ type: 'user_text', text: content }] : [];
      if (Array.isArray(content)) {
        const out = [];
        for (const b of content) {
          if (b.type === 'text' && String(b.text || '').trim()) out.push({ type: 'user_text', text: b.text });
          else if (b.type === 'tool_result') out.push({ type: 'tool_result', toolUseId: b.tool_use_id, content: b.content });
        }
        return out;
      }
      return [];
    }
    if (msg.type === 'assistant' && Array.isArray(content)) {
      const out = [];
      for (const b of content) {
        if (b.type === 'text' && String(b.text || '').trim()) out.push({ type: 'text', text: b.text });
        else if (b.type === 'tool_use') out.push({ type: 'tool_use', id: b.id, name: b.name, input: b.input });
      }
      return out;
    }
    // mode / permission-mode / attachment / last-prompt / system / etc. → ignored
    return [];
  } catch {
    return [{ type: 'raw', raw: String(line) }];
  }
}

// Allowlist the fields that render per type, then recursively cap+scrub them.
const RENDER_FIELDS = {
  init: ['model', 'cwd'],
  text: ['text'],
  user_text: ['text'],
  tool_use: ['name', 'input'],
  tool_result: ['toolUseId', 'content'],
  turn_done: ['result'],
  error: ['code', 'message'],
  raw: ['raw']
};

export function redactSessionEvent(ev) {
  const fields = RENDER_FIELDS[ev.type] || Object.keys(ev).filter((k) => k !== 'type');
  const out = { type: ev.type };
  for (const f of fields) if (f in ev) out[f] = redactValue(ev[f]);
  // carry non-rendered control fields through untouched (seq/turnId/isError/id)
  for (const k of ['seq', 'turnId', 'isError', 'id', 'sessionId']) if (k in ev) out[k] = ev[k];
  return out;
}
