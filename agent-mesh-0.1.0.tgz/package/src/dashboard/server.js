/**
 * src/dashboard/server.js
 *
 * Shell (I/O, Node http) — read-only dashboard HTTP server.
 *
 * Usage:
 *   const srv = createDashboardServer({ meshRoot, port, token });
 *   await srv.start();
 *   // srv.url  → e.g. "http://127.0.0.1:7077"
 *   // srv.close() → stops the server
 */

import { createServer } from 'node:http';
import { readFile, readdir, stat, realpath } from 'node:fs/promises';
import { readFileSync, writeFileSync, mkdirSync, chmodSync } from 'node:fs';
import { join, relative, resolve, extname, dirname, isAbsolute, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';

import { readManifest } from '../builder/manifest.js';
import { discoverAgentStructure } from '../agent-context.js';
import { buildAgentCard } from '../a2a/protocol.js';
import { isPathInsideRoot } from '../path-guard.js';
import {
  meshView,
  treeView,
  resourcesView,
  skillsView,
  mcpsView,
  isSensitivePath
} from './data.js';
import { extractSkillSummary, listLocalSkills } from '../agent-context.js';
import { createConsoleBroker, ConsoleError } from './console.js';
import { createMeshWatcher } from './watcher.js';
import { buildActivity } from './activity.js';
import { createShellLauncher } from './shell-launcher.js';
import { createSessionRunner } from './session-runner.js';
import { listSessions as defaultListSessions, resolveTranscript as defaultResolveTranscript, recordEvent as defaultRecordEvent, deleteSession as defaultDeleteSession, setLabel as defaultSetLabel, deleteLabel as defaultDeleteLabel, readLabels as defaultReadLabels } from './session-index.js';
import { createSessionMirror } from './session-mirror.js';
import { parseTranscriptLine, redactSessionEvent } from './session-events.js';
import { readSessionId, writeSessionId } from './session-store.js';
import { readRunLogRecords, dedupeRunRecords } from '../log.js';
import { MAX_TASK_CHARS } from '../config.js';
import { fetchRemoteImage, defaultPinnedFetch } from './img-proxy.js';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const FILE_SIZE_CAP = 512 * 1024; // 512 KB
const COOKIE_NAME = 'am_dash';

// Console request-body cap: the brokered task text can be at most MAX_TASK_CHARS,
// plus a small allowance for the JSON envelope ({"text":...,"mode":"ask"}).
const CONSOLE_BODY_CAP = MAX_TASK_CHARS + 1024;

// Absolute path to this file's directory (ESM-safe)
const __dirname = dirname(fileURLToPath(import.meta.url));

// Public directory: src/dashboard/public/
const PUBLIC_DIR = join(__dirname, 'public');

// MIME types for static assets
const STATIC_MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.js':   'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.ico':  'image/x-icon',
  '.png':  'image/png',
  '.svg':  'image/svg+xml',
  '.txt':  'text/plain; charset=utf-8'
};

// Text MIME types: we serve these as text; everything else → metadata stub
const TEXT_EXTENSIONS = new Set([
  '.md', '.txt', '.json', '.js', '.mjs', '.cjs', '.ts', '.tsx',
  '.jsx', '.py', '.sh', '.bash', '.zsh', '.fish', '.yaml', '.yml',
  '.toml', '.ini', '.cfg', '.conf', '.env.example', '.gitignore',
  '.dockerignore', '.html', '.css', '.xml', '.csv', '.log', '.sql',
  '.rs', '.go', '.java', '.rb', '.php', '.c', '.cpp', '.h', '.hpp',
  '.swift', '.kt', '.kts', '.scala', '.r', '.m', '.mts', '.cts'
]);

function isTextFile(filePath) {
  const ext = extname(filePath).toLowerCase();
  // No extension → likely a text file (Makefile, Dockerfile, etc.)
  if (!ext) return true;
  return TEXT_EXTENSIONS.has(ext);
}

// ---------------------------------------------------------------------------
// Security headers applied to every response
// ---------------------------------------------------------------------------

function applySecurityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  // Scripts stay locked to 'self' (no 'unsafe-inline' for scripts → XSS boundary
  // intact; all JS is in external CSP-safe files). Styles need 'unsafe-inline'
  // because the app sets dynamic inline styles (pane resize widths, graph tooltip
  // positioning) and pulls the webfont CSS from Google Fonts; without this the
  // browser console filled with CSP violations and resize/tooltip styling was
  // dropped. Inline styles cannot execute script, and rendered HTML is sanitized
  // by render-core, so this does not widen the XSS surface.
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self'; " +
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src 'self' https://fonts.gstatic.com"
  );
}

// ---------------------------------------------------------------------------
// Cookie helpers
// ---------------------------------------------------------------------------

function parseCookies(cookieHeader) {
  const cookies = {};
  if (!cookieHeader) return cookies;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx < 0) continue;
    const key = part.slice(0, idx).trim();
    const val = part.slice(idx + 1).trim();
    cookies[key] = val;
  }
  return cookies;
}

// ---------------------------------------------------------------------------
// Same-origin gate
// ---------------------------------------------------------------------------

/**
 * Enforce same-origin policy:
 *  - parsed Host authority hostname ∈ {127.0.0.1, localhost}
 *  - Host port matches listener port
 *  - Sec-Fetch-Site: same-origin|none  OR  Origin matches listener origin
 *
 * Returns true if the request passes; false (should reject) otherwise.
 *
 * @param {object} req    IncomingMessage
 * @param {number} listenerPort
 * @returns {boolean}
 */
function passesSameOriginGate(req, listenerPort) {
  const hostHeader = req.headers['host'] ?? '';
  const portStr = String(listenerPort);

  // Parse host header: host[:port]
  let hostName, hostPort;
  const bracketMatch = hostHeader.match(/^\[(.+)\]:?(\d*)$/);
  if (bracketMatch) {
    hostName = bracketMatch[1];
    hostPort = bracketMatch[2] || String(listenerPort);
  } else {
    const parts = hostHeader.split(':');
    hostName = parts[0];
    hostPort = parts[1] ?? portStr;
  }

  // Hostname must be 127.0.0.1 or localhost
  if (hostName !== '127.0.0.1' && hostName !== 'localhost') return false;
  // Port must match listener
  if (hostPort !== portStr) return false;

  // Check Sec-Fetch-Site
  const sfs = req.headers['sec-fetch-site'];
  if (sfs === 'same-origin' || sfs === 'none') return true;

  // Check Origin header as fallback (for browsers that don't send Sec-Fetch-Site)
  const origin = req.headers['origin'];
  if (origin) {
    const expectedOrigin = `http://127.0.0.1:${listenerPort}`;
    const expectedOriginLocal = `http://localhost:${listenerPort}`;
    if (origin === expectedOrigin || origin === expectedOriginLocal) return true;
    return false;
  }

  // No Sec-Fetch-Site and no Origin: allow (e.g. top-level nav, curl)
  return true;
}

// ---------------------------------------------------------------------------
// Token comparison (timing-safe)
// ---------------------------------------------------------------------------

function tokenEquals(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  if (a.length !== b.length) return false;
  try {
    return timingSafeEqual(Buffer.from(a, 'utf8'), Buffer.from(b, 'utf8'));
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Snapshot loading (I/O)
// ---------------------------------------------------------------------------

async function loadDashboardSnapshot(meshRoot) {
  // Read manifest
  let manifest = null;
  try {
    manifest = await readManifest(meshRoot);
  } catch {
    manifest = null;
  }

  // Build global skills list from mesh/skills/
  const globalSkills = [];
  const meshSkillsDir = join(meshRoot, 'mesh', 'skills');
  try {
    const entries = await readdir(meshSkillsDir, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const skillPath = join(meshSkillsDir, entry.name, 'SKILL.md');
      try {
        const summary = await extractSkillSummary(skillPath);
        globalSkills.push({ name: entry.name, summary });
      } catch { /* skip */ }
    }
  } catch { /* no mesh/skills dir */ }

  // Global MCP from mesh/mcp.json
  const globalMcps = [];
  const meshMcpPath = join(meshRoot, 'mesh', 'mcp.json');
  try {
    const raw = JSON.parse(await readFile(meshMcpPath, 'utf8'));
    const servers = raw.mcpServers ?? {};
    for (const [name, config] of Object.entries(servers)) {
      globalMcps.push({ name, config });
    }
  } catch { /* no global mcp */ }

  // Per-agent data
  const agentSkills = new Map();
  const agentMcps = new Map();
  const filesByAgent = new Map();
  const meshFilesList = [];

  const agents = manifest?.agents ?? [];

  for (const agentEntry of agents) {
    const agentRoot = join(meshRoot, agentEntry.root);

    // Per-agent skills — discovered across all skill-root conventions
    // (skills/, .claude/skills/, .agent/skills/) so a converted agent's existing
    // skills surface here, matching what the worker runtime sees.
    const aSkills = [];
    for (const skill of await listLocalSkills(agentRoot)) {
      try {
        const summary = await extractSkillSummary(skill.path);
        aSkills.push({ name: skill.name, summary });
      } catch { /* skip */ }
    }
    agentSkills.set(agentEntry.name, aSkills);

    // Per-agent MCPs
    const agentMcpPath = join(agentRoot, '.mcp.json');
    const aMcps = [];
    try {
      const raw = JSON.parse(await readFile(agentMcpPath, 'utf8'));
      const servers = raw.mcpServers ?? {};
      for (const [name, config] of Object.entries(servers)) {
        aMcps.push({ name, config });
      }
    } catch { /* no .mcp.json */ }
    agentMcps.set(agentEntry.name, aMcps);

    // Per-agent file tree
    const aFiles = [];
    await collectFiles(agentRoot, agentRoot, aFiles);
    filesByAgent.set(agentEntry.name, aFiles);
  }

  // Mesh-level file tree
  await collectFiles(meshRoot, meshRoot, meshFilesList);

  return {
    manifest,
    globalSkills,
    globalMcps,
    agentSkills,
    agentMcps,
    filesByAgent,
    meshFiles: meshFilesList,
    conformanceByAgent: new Map()
  };
}

/**
 * Recursively collect relative paths under `root` starting from `dir`.
 * Skips sensitive paths.
 *
 * @param {string} baseRoot  root for relative path calculation
 * @param {string} dir       current directory
 * @param {string[]} result  output array
 */
// Bound the explorer walk so a huge agent folder (e.g. a 50k-file vault copied
// into the mesh) cannot make /api/tree allocate and serialize an unbounded list
// or lag the browser rendering it. Past the cap we stop descending; the explorer
// shows a representative prefix rather than every file.
const MAX_TREE_ENTRIES = 4000;
const MAX_TREE_DEPTH = 12;

async function collectFiles(baseRoot, dir, result, depth = 0) {
  if (result.length >= MAX_TREE_ENTRIES || depth > MAX_TREE_DEPTH) return;
  let entries;
  try {
    entries = await readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const entry of entries) {
    if (result.length >= MAX_TREE_ENTRIES) return;
    const absPath = join(dir, entry.name);
    const relPath = relative(baseRoot, absPath);
    if (isSensitivePath(relPath)) continue;
    if (entry.isDirectory()) {
      result.push(relPath + '/');
      await collectFiles(baseRoot, absPath, result, depth + 1);
    } else if (entry.isFile()) {
      result.push(relPath);
    }
  }
}

// ---------------------------------------------------------------------------
// Activity snapshot (I/O): read recent run logs across agents → buildActivity.
// Only the redacted view-model leaves this function (no log_path/stdout/stderr).
// ---------------------------------------------------------------------------

const ACTIVITY_DATE_FILES = 3;       // most recent date files to scan per agent
const ACTIVITY_RUNS_PER_AGENT = 25;  // most recent runs per agent to surface

async function loadActivitySnapshot(meshRoot) {
  let manifest = null;
  try { manifest = await readManifest(meshRoot); } catch { manifest = null; }
  const agents = manifest?.agents ?? [];
  const records = [];
  for (const agent of agents) {
    const logDir = join(meshRoot, agent.root, '.agent-mesh', 'logs');
    let files = [];
    try { files = await readdir(logDir); } catch { continue; }
    // Grouped per-date files (delegate-YYYY-MM-DD.jsonl) — newest dates last; also
    // tolerate any legacy per-run delegate-*.json. Exclude path-guard-denials.jsonl.
    const logFiles = files
      .filter((f) => f.startsWith('delegate-') && (f.endsWith('.jsonl') || f.endsWith('.json')))
      .sort()
      .slice(-ACTIVITY_DATE_FILES);
    let agentRecords = [];
    for (const f of logFiles) {
      const recs = await readRunLogRecords(join(logDir, f));
      for (const r of recs) agentRecords.push(r);
    }
    // Collapse start+final per run id, keep the most recent runs.
    agentRecords = dedupeRunRecords(agentRecords)
      .sort((a, b) => String(a.started_at || '').localeCompare(String(b.started_at || '')))
      .slice(-ACTIVITY_RUNS_PER_AGENT);
    for (const r of agentRecords) records.push({ ...r, agent: agent.name });
  }
  return buildActivity(records);
}

// ---------------------------------------------------------------------------
// Response helpers
// ---------------------------------------------------------------------------

function sendJson(res, status, body) {
  const json = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(json)
  });
  res.end(json);
}

function sendText(res, status, text, contentType = 'text/plain') {
  const buf = Buffer.from(text, 'utf8');
  res.writeHead(status, {
    'Content-Type': contentType,
    'Content-Length': buf.length
  });
  res.end(buf);
}

function send403(res, reason = 'Forbidden') {
  applySecurityHeaders(res);
  sendText(res, 403, reason);
}

function send404(res) {
  applySecurityHeaders(res);
  sendText(res, 404, 'Not Found');
}

/**
 * Read a request body up to `cap` bytes. Resolves with the UTF-8 string, or
 * rejects with an Error tagged `.tooLarge` if the cap is exceeded (the caller
 * maps that to 413). Aborts cleanly on a destroyed/aborted request.
 *
 * @param {object} req  IncomingMessage
 * @param {number} cap  max bytes
 * @returns {Promise<string>}
 */
function readBodyCapped(req, cap) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    let settled = false;
    req.on('data', (chunk) => {
      if (settled) return;
      size += chunk.length;
      if (size > cap) {
        settled = true;
        const err = new Error('request body too large');
        err.tooLarge = true;
        // Stop reading but leave the socket intact so the route can still send
        // a 413 response; destroying req here would reset the connection.
        req.pause();
        reject(err);
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => { if (!settled) { settled = true; resolve(Buffer.concat(chunks).toString('utf8')); } });
    req.on('error', (e) => { if (!settled) { settled = true; reject(e); } });
  });
}

// Map a ConsoleError code → HTTP status. Domain rejections (the agent/mesh said
// "no") return 200 with { ok:false, error } so the canvas renders them uniformly;
// malformed input is a 4xx; everything else is a 5xx.
function consoleErrorStatus(code) {
  switch (code) {
    case 'mode_disabled':
    case 'not_served':
    case 'stale_registry':
      return 200;
    case 'bad_input':
      return 400;
    case 'aborted':
      return 499; // client closed request
    default:
      return 502; // spawn_failed / internal
  }
}

// ---------------------------------------------------------------------------
// Route handling
// ---------------------------------------------------------------------------

async function handleRequest(req, res, { meshRoot, token, listenerPort, consoleBroker, chatEnabled, sse, shellLauncher, sessionRunner, sessionIndex, sessionMirror, sessionLogEnabled, fetchImage, mirrorStreams }) {
  applySecurityHeaders(res);

  const url = new URL(req.url ?? '/', `http://127.0.0.1:${listenerPort}`);
  const pathname = url.pathname;

  // -----------------------------------------------------------------------
  // Bootstrap route: GET /?t=<token>
  // -----------------------------------------------------------------------
  if (pathname === '/' && req.method === 'GET' && url.searchParams.has('t')) {
    const candidate = url.searchParams.get('t');
    if (!tokenEquals(candidate, token)) {
      send403(res, 'Invalid token');
      return;
    }
    // Set cookie and redirect to clean URL
    res.setHeader(
      'Set-Cookie',
      `${COOKIE_NAME}=${token}; SameSite=Strict; HttpOnly; Path=/`
    );
    res.writeHead(302, { Location: '/' });
    res.end();
    return;
  }

  // -----------------------------------------------------------------------
  // All other routes: require same-origin gate + cookie
  // -----------------------------------------------------------------------

  // Same-origin gate
  if (!passesSameOriginGate(req, listenerPort)) {
    send403(res, 'Cross-origin request denied');
    return;
  }

  // Cookie auth
  const cookies = parseCookies(req.headers['cookie']);
  const cookieVal = cookies[COOKIE_NAME] ?? '';
  if (!tokenEquals(cookieVal, token)) {
    send403(res, 'Authentication required');
    return;
  }

  // -----------------------------------------------------------------------
  // API routes
  // -----------------------------------------------------------------------

  if (pathname === '/api/mesh' && req.method === 'GET') {
    const snapshot = await loadDashboardSnapshot(meshRoot);
    const view = meshView(snapshot);
    view.shellEnabled = !!shellLauncher;       // gate the native-CLI button in the UI
    view.sessionLogEnabled = sessionLogEnabled; // gate the session-log view (list/transcript)
    view.chatEnabled = !!chatEnabled;           // gate the in-dashboard chat composer (off by default)
    sendJson(res, 200, view);
    return;
  }

  // GET /api/resources → mesh + per-agent grouped skills/MCP for the board's
  // "resources" view. The frontend (app.js) fetches this; the route was missing
  // (resourcesView was imported but never wired), so the board 404'd.
  if (pathname === '/api/resources' && req.method === 'GET') {
    const snapshot = await loadDashboardSnapshot(meshRoot);
    sendJson(res, 200, resourcesView(snapshot));
    return;
  }

  // GET /api/agent/:name/worklog → { exists, path, content } for that agent's
  // WORK_LOG.md (a per-agent maintenance log distilled from sessions: why
  // decisions were made, blockers, next steps — the curated companion to the
  // raw session transcript). Missing file is 200 { exists:false } so the
  // frontend can show a "create one" empty state without a 404 round-trip.
  if (pathname.startsWith('/api/agent/') && pathname.endsWith('/worklog') && req.method === 'GET') {
    const inner = pathname.slice('/api/agent/'.length, -'/worklog'.length);
    const name = decodeURIComponent(inner);
    if (!name) { send404(res); return; }

    const snapshot = await loadDashboardSnapshot(meshRoot);
    const entry = snapshot?.manifest?.agents?.find(a => a.name === name);
    if (!entry) { send404(res); return; }

    const agentRoot = resolve(join(meshRoot, entry.root));
    const inside = await isPathInsideRoot(meshRoot, agentRoot).catch(() => false);
    if (!inside) { send403(res, 'Agent root escapes mesh boundary'); return; }

    const wlPath = join(agentRoot, 'WORK_LOG.md');
    try {
      const content = await readFile(wlPath, 'utf8');
      sendJson(res, 200, { exists: true, path: wlPath, content });
    } catch {
      sendJson(res, 200, { exists: false, path: wlPath, content: '' });
    }
    return;
  }

  if (pathname.startsWith('/api/agent/') && !pathname.includes('/session/') && req.method === 'GET') {
    const name = decodeURIComponent(pathname.slice('/api/agent/'.length));
    if (!name) { send404(res); return; }

    const snapshot = await loadDashboardSnapshot(meshRoot);
    const agents = snapshot?.manifest?.agents ?? [];
    const entry = agents.find(a => a.name === name);
    if (!entry) { send404(res); return; }

    // Containment check
    const agentRoot = resolve(join(meshRoot, entry.root));
    const inside = await isPathInsideRoot(meshRoot, agentRoot).catch(() => false);
    if (!inside) {
      send403(res, 'Agent root escapes mesh boundary');
      return;
    }

    const structure = await discoverAgentStructure(agentRoot, { meshRoot: join(meshRoot, 'mesh') });
    let agentJson = null;
    try {
      agentJson = JSON.parse(await readFile(join(agentRoot, 'agent.json'), 'utf8'));
    } catch { /* absent */ }
    const card = buildAgentCard({
      self: agentJson,
      root: agentRoot,
      url: `agent-mesh://${name}`,
      modes: entry.enabledModes
    });

    sendJson(res, 200, { name, entry, structure, card });
    return;
  }

  if (pathname === '/api/tree' && req.method === 'GET') {
    const scope = url.searchParams.get('scope') ?? 'mesh';
    const snapshot = await loadDashboardSnapshot(meshRoot);
    const tree = treeView(snapshot, scope);
    sendJson(res, 200, tree);
    return;
  }

  if (pathname === '/api/file' && req.method === 'GET') {
    const rawPath = url.searchParams.get('path') ?? '';
    if (!rawPath) {
      send403(res, 'Missing path parameter');
      return;
    }
    const scope = url.searchParams.get('scope') ?? 'mesh';

    // Resolve relative paths against the scope's base:
    //   scope=mesh (or missing)        → meshRoot
    //   scope=<agent-name>             → meshRoot/<agent.root>  (from the manifest)
    //   absolute path                  → as-is (still validated below)
    // The frontend builds explorer paths relative to the current scope
    // (treeView in src/dashboard/data.js), so file fetches must anchor the
    // same way or they collapse to process.cwd() and 403 as "outside root".
    let base = meshRoot;
    if (!isAbsolute(rawPath) && scope !== 'mesh') {
      try {
        const snap = await loadDashboardSnapshot(meshRoot);
        const agent = snap?.manifest?.agents?.find((a) => a.name === scope);
        if (agent?.root) base = resolve(meshRoot, agent.root);
      } catch { /* fall back to meshRoot — final inside-root check will catch escapes */ }
    }
    const candidate = isAbsolute(rawPath) ? resolve(rawPath) : resolve(base, rawPath);
    const inside = await isPathInsideRoot(meshRoot, candidate).catch(() => false);
    if (!inside) {
      send403(res, 'Path outside mesh root');
      return;
    }

    // Sensitive check (use relative path from meshRoot)
    let canonRoot;
    try { canonRoot = await realpath(meshRoot); } catch { canonRoot = meshRoot; }
    const rel = relative(canonRoot, candidate);
    if (isSensitivePath(rel)) {
      send403(res, 'Sensitive path denied');
      return;
    }

    // Stat
    let fileStat;
    try {
      fileStat = await stat(candidate);
    } catch {
      send404(res);
      return;
    }
    if (!fileStat.isFile()) {
      send403(res, 'Not a file');
      return;
    }

    // Size cap
    if (fileStat.size > FILE_SIZE_CAP) {
      sendJson(res, 200, {
        kind: 'metadata',
        path: rel,
        size: fileStat.size,
        reason: 'file_too_large'
      });
      return;
    }

    // Text-only
    if (!isTextFile(candidate)) {
      sendJson(res, 200, {
        kind: 'metadata',
        path: rel,
        size: fileStat.size,
        reason: 'binary_file'
      });
      return;
    }

    // Read and serve
    let content;
    try {
      content = await readFile(candidate, 'utf8');
    } catch {
      send404(res);
      return;
    }

    sendJson(res, 200, { kind: 'text', path: rel, content });
    return;
  }

  if (pathname === '/api/skills' && req.method === 'GET') {
    const snapshot = await loadDashboardSnapshot(meshRoot);
    const skills = skillsView(snapshot);
    sendJson(res, 200, skills);
    return;
  }

  if (pathname === '/api/mcps' && req.method === 'GET') {
    const snapshot = await loadDashboardSnapshot(meshRoot);
    const mcps = mcpsView(snapshot);
    sendJson(res, 200, mcps);
    return;
  }

  // -----------------------------------------------------------------------
  // Live change stream: GET /api/events (SSE) — coarse, secret-safe.
  // -----------------------------------------------------------------------
  if (pathname === '/api/events' && req.method === 'GET' && sse) {
    await sse.addClient(req, res);
    return;
  }

  // -----------------------------------------------------------------------
  // Live board activity: GET /api/activity — redacted agent/edge/event model.
  // -----------------------------------------------------------------------
  if (pathname === '/api/activity' && req.method === 'GET') {
    sendJson(res, 200, await loadActivitySnapshot(meshRoot));
    return;
  }

  // -----------------------------------------------------------------------
  // Image proxy: GET /api/img?url=  (gated: allowShell OR injected imgFetcher + auth)
  // -----------------------------------------------------------------------
  if (pathname === '/api/img' && req.method === 'GET') {
    if (!fetchImage) { sendJson(res, 403, { ok: false, error: { code: 'shell_disabled', message: 'image proxy is disabled; start the dashboard with --allow-shell' } }); return; }
    const imgUrl = url.searchParams.get('url') ?? '';
    try {
      const { contentType, body } = await fetchImage(imgUrl);
      res.writeHead(200, {
        'Content-Type': contentType,
        'X-Content-Type-Options': 'nosniff',
        'Content-Length': body.length,
        'Cache-Control': 'private, max-age=300'
      });
      res.end(body);
    } catch (err) {
      // Only surface img-proxy's deliberate domain codes; coerce any Node
      // internal (ERR_INVALID_URL / ENOTFOUND / ECONNRESET …) to a generic code
      // so getaddrinfo names / upstream details don't leak to the client.
      const KNOWN = new Set(['scheme', 'host', 'address', 'redirect', 'upstream', 'content_type', 'magic', 'too_large', 'timeout']);
      const code = KNOWN.has(err.code) ? err.code : 'img_error';
      sendJson(res, 400, { ok: false, error: { code, message: code === 'img_error' ? 'image request failed' : err.message } });
    }
    return;
  }

  // -----------------------------------------------------------------------
  // Native CLI entry point (PRIVILEGED, opt-in): plan → launch.
  //   POST /api/agent/:name/shell/plan    → { planId, command } and reserves
  //        the agent's canonical session id when one does not exist yet
  //   POST /api/agent/:name/shell/launch  → opens the operator's terminal
  // Disabled unless the dashboard was started with allowShell.
  // -----------------------------------------------------------------------
  if (pathname.startsWith('/api/agent/') &&
      (pathname.endsWith('/shell/plan') || pathname.endsWith('/shell/launch')) &&
      req.method === 'POST') {
    if (!shellLauncher) { sendJson(res, 403, { ok: false, error: { code: 'shell_disabled', message: 'native CLI launch is disabled; start the dashboard with --allow-shell' } }); return; }

    const isPlan = pathname.endsWith('/shell/plan');
    const suffix = isPlan ? '/shell/plan' : '/shell/launch';
    const name = decodeURIComponent(pathname.slice('/api/agent/'.length, -suffix.length));
    if (!name) { send404(res); return; }

    // membership + containment (gate before any side effect)
    const snapshot = await loadDashboardSnapshot(meshRoot);
    const entry = (snapshot?.manifest?.agents ?? []).find(a => a.name === name);
    if (!entry) { send404(res); return; }
    let canonRoot;
    try { canonRoot = await realpath(resolve(join(meshRoot, entry.root))); } catch { send404(res); return; }
    const inside = await isPathInsideRoot(meshRoot, canonRoot).catch(() => false);
    if (!inside) { send403(res, 'Agent root escapes mesh boundary'); return; }

    let body;
    try { body = JSON.parse((await readBodyCapped(req, 4096)) || '{}'); }
    catch (err) { sendJson(res, err.tooLarge ? 413 : 400, { ok: false, error: { code: 'bad_input' } }); return; }

    try {
      if (isPlan) {
        let sessionId = await readSessionId(meshRoot, canonRoot);
        if (!sessionId) {
          sessionId = randomUUID();
          await writeSessionId(meshRoot, canonRoot, sessionId);
        }

        const resolveShellTranscript = sessionIndex?.resolveTranscript
          ? (root, id) => sessionIndex.resolveTranscript(root, id)
          : (root, id) => defaultResolveTranscript(root, id, { meshRoot });
        let hasTranscript = false;
        try {
          await resolveShellTranscript(canonRoot, sessionId);
          hasTranscript = true;
        } catch (err) {
          if (err.code !== 'not_found') throw err;
        }

        const plan = hasTranscript
          ? await shellLauncher.buildPlan({ agentRoot: canonRoot, entry, resumeId: sessionId })
          : await shellLauncher.buildPlan({ agentRoot: canonRoot, entry, sessionId });
        sendJson(res, 200, { ok: true, ...plan });
      } else {
        const result = await shellLauncher.launch(String(body.planId || ''));
        sendJson(res, 200, result);
      }
    } catch (err) {
      const code = err.code || 'internal';
      const status = code === 'reserved_name' ? 409 : code === 'plan_expired' ? 410 : code === 'bad_input' ? 400 : 500;
      sendJson(res, status, { ok: false, error: { code, message: err.message } });
    }
    return;
  }

  // -----------------------------------------------------------------------
  // Session log + live mirror (PRIVILEGED, opt-in):
  //   GET  /api/agent/:name/session/list           → session rows (index)
  //   GET  /api/agent/:name/session/:id/transcript → windowed line records (index)
  //   GET  /api/agent/:name/session/:id/stream     → SSE live mirror of the
  //        transcript tail (iTerm→dashboard); seq = transcript line index
  //   POST /api/agent/:name/session/message        → 202 { turnId } (driven turn)
  //   POST /api/agent/:name/session/stop           → 200 { ok }
  // Disabled unless the dashboard was started with --allow-shell.
  // -----------------------------------------------------------------------
  if (pathname.startsWith('/api/agent/') && pathname.includes('/session/')) {
    if (!sessionRunner && !sessionMirror && !sessionIndex) { sendJson(res, 403, { ok: false, error: { code: 'shell_disabled', message: 'native session is disabled; start the dashboard with --allow-shell' } }); return; }
    // Two forms: the flat per-agent verbs (message/stop/list), and the id-bearing
    // routes (transcript + the live mirror stream + resume/select). A malicious id
    // is constrained by the 36-char UUID shape and, on transcript/stream, still
    // routes through resolveTranscript (containment), never a hand-joined path.
    // `resume` is the single-active selection verb (setActiveSession); the
    // expectedActiveId echoed back on the next /message is a client-supplied
    // OPTIMISTIC-CONCURRENCY token compared against server state — it never feeds
    // the writable root / call-path / depth (those come from process env in the
    // runner). open-terminal launches an INDEPENDENT terminal-owned `claude
    // --resume <id>` session (no lease — the external terminal owns its own
    // session; single-active still applies at the lease layer when a turn runs).
    const m = pathname.match(/^\/api\/agent\/(.+?)\/session\/(?:(message|stop|list)|([0-9a-f-]{36})\/(transcript|stream|resume|open-terminal|rename|delete))$/i);
    if (!m) { send404(res); return; }
    const name = decodeURIComponent(m[1]);
    const id = m[3] || null;
    const verb = m[2] || m[4];

    // membership + containment (gate before any side effect)
    const snapshot = await loadDashboardSnapshot(meshRoot);
    const entry = (snapshot?.manifest?.agents ?? []).find(a => a.name === name);
    if (!entry) { send404(res); return; }
    const agentRoot = resolve(join(meshRoot, entry.root));
    const inside = await isPathInsideRoot(meshRoot, agentRoot).catch(() => false);
    if (!inside) { send403(res, 'Agent root escapes mesh boundary'); return; }

    if (verb === 'list' && req.method === 'GET') {
      if (!sessionIndex) { sendJson(res, 503, { ok: false, error: { code: 'session_index_unavailable', message: 'session index backend is not available' } }); return; }
      const canonRoot = await realpath(agentRoot).catch(() => agentRoot);
      const sessions = await sessionIndex.listSessions(canonRoot);
      sendJson(res, 200, { ok: true, sessions });
      return;
    }

    // GET /session/:id/transcript?beforeSeq=&limit=
    // A windowed slice of line records { seq, events } where seq = the 1-based
    // transcript LINE INDEX — the same cursor the live /stream mirror emits, so
    // both agree. Reverse pagination: return records with seq < beforeSeq, keeping
    // the newest `limit` of them. The id → transcript path resolution goes through
    // resolveTranscript (UUID + index-only + realpath containment); paths are never
    // hand-joined here. Malformed transcript lines degrade to a `raw` event and are
    // never thrown.
    if (verb === 'transcript' && req.method === 'GET') {
      if (!sessionIndex) { sendJson(res, 503, { ok: false, error: { code: 'session_index_unavailable', message: 'session index backend is not available' } }); return; }
      const canonRoot = await realpath(agentRoot).catch(() => agentRoot);
      let transcriptPath;
      try {
        transcriptPath = await sessionIndex.resolveTranscript(canonRoot, id);
      } catch (e) {
        // bad_id / not_found / containment → a clean 404; never a crash or traversal.
        sendJson(res, 404, { ok: false, error: { code: e.code || 'not_found' } });
        return;
      }
      const beforeSeq = Number(url.searchParams.get('beforeSeq') || 0) || Infinity;
      const limit = Math.max(1, Math.min(500, Number(url.searchParams.get('limit') || 200) || 200));
      const raw = await readFile(transcriptPath, 'utf8').catch(() => '');
      const lines = raw.split('\n');
      const records = [];
      for (let i = 0; i < lines.length; i++) {
        const seq = i + 1; // 1-based line index cursor (matches the mirror)
        if (!lines[i].trim()) continue;
        const events = parseTranscriptLine(lines[i]).map(redactSessionEvent);
        if (events.length) records.push({ seq, events });
      }
      // Newest-last window of <=limit records ending before beforeSeq.
      const windowed = records.filter((r) => r.seq < beforeSeq).slice(-limit);
      sendJson(res, 200, {
        ok: true,
        records: windowed,
        hasMore: windowed.length > 0 && windowed[0].seq > 1,
        nextCursor: windowed.length ? windowed[0].seq : null
      });
      return;
    }

    // GET /session/:id/stream — the live iTerm→dashboard mirror. The canvas's
    // SINGLE content cursor: seq = transcript LINE INDEX (the same cursor the
    // windowed /transcript route emits), so a reconnecting client can resume with
    // Last-Event-ID and the two views stay in lockstep. This supersedes the old
    // driven runner-hub SSE: an iTerm-driven session and a dashboard-driven turn
    // both write the same transcript, so both appear here through one tail.
    if (verb === 'stream' && req.method === 'GET') {
      if (!sessionMirror) { sendJson(res, 503, { ok: false, error: { code: 'session_mirror_unavailable', message: 'session mirror backend is not available' } }); return; }
      if (!sessionIndex) { sendJson(res, 503, { ok: false, error: { code: 'session_index_unavailable', message: 'session index backend is not available' } }); return; }
      const canonRoot = await realpath(agentRoot).catch(() => agentRoot);
      let transcriptPath;
      try {
        transcriptPath = await sessionIndex.resolveTranscript(canonRoot, id);
      } catch (e) {
        // bad_id / not_found / containment → a clean 404; never a crash or traversal.
        sendJson(res, 404, { ok: false, error: { code: e.code || 'not_found' } });
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive' });
      res.write(': connected\n\n');
      // Resume cursor. A fresh browser EventSource cannot set Last-Event-ID (the
      // browser only sends it on its OWN auto-reconnects), so the frontend threads
      // its transcript cursor via ?fromSeq= on the initial open. Precedence:
      //   Last-Event-ID header (mid-stream auto-reconnect)  >  ?fromSeq query  >  0
      // This seals the past→live handoff: the live tail starts exactly where the
      // rendered transcript ended (no double-render, no subscribe-at-0 gap loop).
      const headerSeq = Number(req.headers['last-event-id'] || 0) || 0;
      const querySeq = Number(url.searchParams.get('fromSeq') || 0) || 0;
      const lastSeq = Math.max(0, req.headers['last-event-id'] != null ? headerSeq : querySeq);
      // subscribe() is async (it awaits the tailer's initial drain so the cursor
      // decision sees the file at EOF). The client could disconnect during that
      // await, so register teardown against a `let sub` that may still be null:
      // closed=true then short-circuits the assignment + closes immediately.
      let sub = null;
      let closed = false;
      const ping = setInterval(() => { try { res.write(': ping\n\n'); } catch { /* ignore */ } }, 25_000);
      ping.unref?.();
      // Track this live response so srv.close() can end it (an active streaming
      // response otherwise blocks httpServer.close() until the keep-alive timeout).
      mirrorStreams?.add(res);
      // Teardown: release the mirror subscription + heartbeat on disconnect so we
      // never leak a subscriber (and, when it's the last one, the mirror pauses its
      // file watcher). A prior flakiness source — get it right.
      req.on('close', () => {
        clearInterval(ping);
        closed = true;
        if (sub) sub.close();
        mirrorStreams?.delete(res);
        // The client is gone; tear the server-side socket down rather than leaving
        // it keep-alive-idle (which would hold httpServer.close() open until the
        // keep-alive timeout). end() is best-effort; destroy() guarantees release.
        try { res.end(); } catch { /* already gone */ }
        try { res.socket?.destroy(); } catch { /* already gone */ }
      });
      // Records are already redactSessionEvent-scrubbed inside session-mirror, so
      // no re-redaction here.
      sub = await sessionMirror.subscribe(id, transcriptPath, (rec) => {
        try {
          if (rec && rec.type === 'replay_gap') { res.write('event: gap\ndata: {}\n\n'); return; }
          res.write(`id: ${rec.seq}\nevent: record\ndata: ${JSON.stringify(rec)}\n\n`);
        } catch { /* dead socket; cleanup runs on close */ }
      }, lastSeq);
      // If the client disconnected during the await above, close fired before sub
      // existed — release the now-resolved subscription immediately so it can't leak.
      if (closed) { try { sub.close(); } catch { /* ignore */ } }
      return;
    }

    // POST /session/:id/open-terminal — launch an external terminal running
    // `claude --resume <id>` in the agent's folder. NO lease is taken: the
    // external terminal owns its own claude session; the dashboard just launches
    // it. The id is validated through resolveTranscript (containment) BEFORE any
    // launch — a bad/unknown id is a clean 404, never a launch. Provenance records
    // {kind:'open',source:'terminal'}. We warn the caller that this session runs
    // OUTSIDE dashboard single-active coordination (single-active still applies at
    // the lease layer when a turn actually runs).
    if (verb === 'open-terminal' && req.method === 'POST') {
      if (!shellLauncher) { sendJson(res, 503, { ok: false, error: { code: 'shell_launcher_unavailable', message: 'native CLI launcher backend is not available' } }); return; }
      if (!sessionIndex) { sendJson(res, 503, { ok: false, error: { code: 'session_index_unavailable', message: 'session index backend is not available' } }); return; }
      const canonRoot = await realpath(agentRoot).catch(() => agentRoot);
      // Validate the id resolves to a real session for this agent before launching.
      try {
        await sessionIndex.resolveTranscript(canonRoot, id);
      } catch (e) {
        sendJson(res, 404, { ok: false, error: { code: e.code || 'not_found' } });
        return;
      }
      try {
        const plan = await shellLauncher.buildPlan({ agentRoot: canonRoot, entry, resumeId: id });
        // Single-click UX: chain launch right after buildPlan so the OS terminal
        // actually opens — without this the endpoint returned only the plan and
        // the user had to copy `command` out of the response themselves.
        // shellLauncher.launch is optional only for test stubs; real launchers
        // expose it (see src/dashboard/shell-launcher.js).
        let launched = null;
        if (typeof shellLauncher.launch === 'function') {
          launched = await shellLauncher.launch(plan.planId);
        }
        // Provenance: an external terminal-owned session was opened for this id.
        if (sessionIndex.recordEvent) {
          await sessionIndex.recordEvent(meshRoot, { kind: 'open', source: 'terminal', agentRoot: canonRoot, sessionId: id, terminalApp: process.platform });
        }
        sendJson(res, 200, {
          ok: true,
          ...plan,
          opened: !!(launched && launched.opened),
          warning: 'This opens an independent terminal-owned claude session that runs OUTSIDE dashboard single-active coordination.'
        });
      } catch (err) {
        sendJson(res, err.code === 'reserved_name' ? 409 : 500, { ok: false, error: { code: err.code || 'internal', message: err.message } });
      }
      return;
    }

    // POST /session/:id/rename — set the mesh-side display label for a session.
    // The id is validated through resolveTranscript (UUID + index-membership +
    // realpath containment) BEFORE any write — a bad/unknown id is a clean 404.
    // The label store is mesh-side (~/.agent-mesh/sessions/<hash>/labels.json); it
    // never touches Claude Code's transcript. An empty/blank name clears the label.
    if (verb === 'rename' && req.method === 'POST') {
      if (!sessionIndex) { sendJson(res, 503, { ok: false, error: { code: 'session_index_unavailable', message: 'session index backend is not available' } }); return; }
      let body;
      try { body = JSON.parse((await readBodyCapped(req, CONSOLE_BODY_CAP)) || '{}'); }
      catch (err) { sendJson(res, err.tooLarge ? 413 : 400, { ok: false, error: { code: 'bad_input' } }); return; }
      const canonRoot = await realpath(agentRoot).catch(() => agentRoot);
      try {
        await sessionIndex.resolveTranscript(canonRoot, id);
      } catch (e) {
        sendJson(res, 404, { ok: false, error: { code: e.code || 'not_found' } });
        return;
      }
      const name = typeof body.name === 'string' ? body.name : '';
      const label = await sessionIndex.setLabel(meshRoot, id, name);
      sendJson(res, 200, { ok: true, label });
      return;
    }

    // POST /session/:id/delete — PERMANENTLY delete the session's real transcript.
    // deleteSession resolves the path via resolveTranscript (the security gate) and
    // unlinks it — never a hand-joined path. Resolve errors (bad/unknown id) → 404.
    // The mesh-side label is also dropped so a recreated id can't inherit it.
    if (verb === 'delete' && req.method === 'POST') {
      if (!sessionIndex) { sendJson(res, 503, { ok: false, error: { code: 'session_index_unavailable', message: 'session index backend is not available' } }); return; }
      const canonRoot = await realpath(agentRoot).catch(() => agentRoot);
      try {
        await sessionIndex.deleteSession(canonRoot, id);
      } catch (e) {
        sendJson(res, 404, { ok: false, error: { code: e.code || 'not_found' } });
        return;
      }
      if (sessionIndex.deleteLabel) { try { await sessionIndex.deleteLabel(meshRoot, id); } catch { /* label drop is best-effort */ } }
      sendJson(res, 200, { ok: true });
      return;
    }

    // message/stop/resume all drive the session runner; without it → 503.
    if ((verb === 'message' || verb === 'stop' || verb === 'resume') && !sessionRunner) {
      sendJson(res, 503, { ok: false, error: { code: 'session_runner_unavailable', message: 'session runner backend is not available' } });
      return;
    }

    // POST /session/:id/resume — select the single active session (no lease, no
    // turn). Returns { activeId, rev }; the frontend echoes activeId as
    // expectedActiveId on the next /message so a concurrent re-select is caught.
    if (verb === 'resume' && req.method === 'POST') {
      // Validate the id resolves to a real session for this agent BEFORE selecting
      // it active (consistent with transcript/stream/open-terminal). A
      // well-formed-but-nonexistent id is a clean 404, not a deferred turn-time
      // failure. Anti-spoof unaffected: id never feeds the writable root/path/depth.
      if (!sessionIndex) { sendJson(res, 503, { ok: false, error: { code: 'session_index_unavailable', message: 'session index backend is not available' } }); return; }
      const canonRoot = await realpath(agentRoot).catch(() => agentRoot);
      try {
        await sessionIndex.resolveTranscript(canonRoot, id);
      } catch (e) {
        sendJson(res, 404, { ok: false, error: { code: e.code || 'not_found' } });
        return;
      }
      try {
        const sel = await sessionRunner.setActiveSession(name, id);
        sendJson(res, 200, { ok: true, ...sel });
      } catch (err) {
        const code = err.code || 'internal';
        const status = code === 'bad_id' ? 400 : code === 'unknown_agent' ? 404 : 500;
        sendJson(res, status, { ok: false, error: { code, message: err.message } });
      }
      return;
    }

    if (verb === 'message' && req.method === 'POST') {
      let body;
      try { body = JSON.parse((await readBodyCapped(req, CONSOLE_BODY_CAP)) || '{}'); }
      catch (err) { sendJson(res, err.tooLarge ? 413 : 400, { ok: false, error: { code: 'bad_input' } }); return; }
      const text = typeof body.text === 'string' ? body.text : '';
      const force = !!body.force;
      // expectedActiveId: client-supplied optimistic-concurrency token. Threaded
      // ONLY into runTurn's active-session check; never into the writable root,
      // call-path, or depth (those are read from process env inside the runner).
      const expectedActiveId = typeof body.expectedActiveId === 'string' ? body.expectedActiveId : undefined;
      try {
        const { turnId } = await sessionRunner.runTurn({ agentName: name, text, force, expectedActiveId });
        sendJson(res, 202, { ok: true, turnId });
      } catch (err) {
        const code = err.code || 'internal';
        // session_busy / session_busy_external (lease held) and active_changed
        // (the active session moved under a stale client) are all 409 — the client
        // reconciles and retries. active_changed carries the current activeId.
        const status = (code === 'session_busy' || code === 'session_busy_external' || code === 'active_changed') ? 409 : code === 'unknown_agent' ? 404 : 500;
        sendJson(res, status, { ok: false, error: { code, message: err.message, owner: err.owner, activeId: err.activeId } });
      }
      return;
    }

    if (verb === 'stop' && req.method === 'POST') {
      await sessionRunner.stop(name);
      sendJson(res, 200, { ok: true });
      return;
    }

    send404(res);
    return;
  }

  // -----------------------------------------------------------------------
  // Console: POST /api/agent/:name/message  { text, mode? }
  // Brokers a real A2A SendMessage (ask-only) and returns the final Task.
  // -----------------------------------------------------------------------
  if (
    pathname.startsWith('/api/agent/') &&
    pathname.endsWith('/message') &&
    req.method === 'POST'
  ) {
    const inner = pathname.slice('/api/agent/'.length, -'/message'.length);
    const name = decodeURIComponent(inner);
    if (!name) { send404(res); return; }

    // In-dashboard chat is off by default — drive Claude from the external CLI.
    if (!chatEnabled) {
      sendJson(res, 403, { ok: false, error: { code: 'chat_disabled', message: 'in-dashboard chat is disabled; start the dashboard with --enable-chat' } });
      return;
    }

    // Read body with cap.
    let raw;
    try {
      raw = await readBodyCapped(req, CONSOLE_BODY_CAP);
    } catch (err) {
      if (err.tooLarge) {
        res.setHeader('Connection', 'close');
        sendJson(res, 413, { ok: false, error: { code: 'too_large', message: 'request body too large' } });
      } else {
        sendJson(res, 400, { ok: false, error: { code: 'bad_input', message: 'could not read request body' } });
      }
      return;
    }

    let body;
    try {
      body = JSON.parse(raw || '{}');
    } catch {
      sendJson(res, 400, { ok: false, error: { code: 'bad_input', message: 'request body must be JSON' } });
      return;
    }

    const text = typeof body.text === 'string' ? body.text : '';
    const mode = typeof body.mode === 'string' ? body.mode : 'ask';

    // Abort the in-flight spawn if the client disconnects.
    const controller = new AbortController();
    const onClose = () => { if (!res.writableEnded) controller.abort(); };
    req.on('close', onClose);

    try {
      const result = await consoleBroker.send({ agentName: name, text, mode, signal: controller.signal });
      if (!res.writableEnded) {
        sendJson(res, 200, { ok: true, task: result.task, delegations: result.delegations });
      }
    } catch (err) {
      const code = err instanceof ConsoleError ? err.code : 'internal';
      const message = err.message || 'console error';
      if (!res.writableEnded) {
        sendJson(res, consoleErrorStatus(code), { ok: false, error: { code, message } });
      }
    } finally {
      req.removeListener('close', onClose);
    }
    return;
  }

  // -----------------------------------------------------------------------
  // Static asset serving: GET / → index.html; GET /app.js, /app.css, etc.
  // Served ONLY behind the auth cookie (already checked above).
  // Path must be within PUBLIC_DIR (no traversal).
  // -----------------------------------------------------------------------

  if (req.method === 'GET') {
    // Map / to index.html
    const assetPath = pathname === '/' ? '/index.html' : pathname;

    // Reject traversal attempts (%2e, double-dot, etc.)
    if (assetPath.includes('..') || assetPath.includes('\0')) {
      send403(res, 'Invalid asset path');
      return;
    }

    // render-core.js is the pure render module (src/dashboard/render-core.js, one
    // level above public) imported by the browser's result-canvas.js as
    // `../render-core.js` → URL `/render-core.js`. Serve it from its real location
    // via an EXACT literal map (no user-controlled path join → no traversal).
    let filePath;
    if (assetPath === '/render-core.js') {
      filePath = join(__dirname, 'render-core.js');
    } else {
      // Build the absolute file path and check it stays inside PUBLIC_DIR
      filePath = join(PUBLIC_DIR, assetPath);
      if (!filePath.startsWith(PUBLIC_DIR + sep) && filePath !== PUBLIC_DIR) {
        send403(res, 'Asset path outside public directory');
        return;
      }
    }

    let fileStat;
    try {
      fileStat = await stat(filePath);
    } catch {
      send404(res);
      return;
    }

    if (!fileStat.isFile()) {
      send404(res);
      return;
    }

    const ext = extname(filePath).toLowerCase();
    const mime = STATIC_MIME[ext] ?? 'application/octet-stream';

    let content;
    try {
      content = await readFile(filePath);
    } catch {
      send404(res);
      return;
    }

    // Disable HTTP caching for the dashboard assets. Without this, every code
    // change requires the user to hard-reload — they otherwise hit a stale
    // app.js/session-log.js and end up with mismatched JS+server (which
    // surfaced as e.g. "scope switch still shows previous agent" because the
    // old setChatAgent closure was still bound). The dashboard is a single-
    // page app served from localhost, so no real cache wins anyway.
    res.writeHead(200, {
      'Content-Type': mime,
      'Content-Length': content.length,
      'Cache-Control': 'no-store, must-revalidate',
      'Pragma': 'no-cache'
    });
    res.end(content);
    return;
  }

  // Unknown route
  send404(res);
}

// ---------------------------------------------------------------------------
// SSE hub: /api/events — coarse, secret-safe change notifications.
// The watcher is created lazily on the first client and torn down when the last
// disconnects, so an idle dashboard does no polling.
// ---------------------------------------------------------------------------

function createSseHub({ meshRoot, pollMs }) {
  const clients = new Set();
  let watcher = null;

  function emit(event, data) {
    const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const res of clients) {
      try { res.write(payload); } catch { /* dead socket; cleanup runs on close */ }
    }
  }

  // On any watched change emit the coarse `change` event AND a fresh, redacted
  // `activity` snapshot (run-log driven). The watcher already debounces, so this
  // re-scan is bounded.
  async function onWatcherChange(evt) {
    emit('change', evt);
    try {
      emit('activity', await loadActivitySnapshot(meshRoot));
    } catch { /* transient; next change retries */ }
  }

  async function ensureWatcher() {
    if (watcher) return;
    let agentDirs = [];
    try {
      const manifest = await readManifest(meshRoot);
      agentDirs = (manifest.agents ?? [])
        .map((a) => String(a.root || '').replace(/^\.\//, '').split('/')[0])
        .filter(Boolean);
    } catch { /* no manifest → scope collapses to 'mesh' */ }
    watcher = createMeshWatcher({
      meshRoot,
      agentDirs,
      pollMs,
      onChange: onWatcherChange
    });
    await watcher.ready;
  }

  async function addClient(req, res) {
    // Establish the watcher baseline BEFORE announcing ': connected' — otherwise
    // a change the client triggers immediately after connecting could be folded
    // into the baseline scan and never reported.
    await ensureWatcher();

    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive'
    });
    res.write(': connected\n\n');
    clients.add(res);

    const heartbeat = setInterval(() => {
      try { res.write(': ping\n\n'); } catch { /* ignore */ }
    }, 25_000);
    heartbeat.unref?.();

    const cleanup = () => {
      clearInterval(heartbeat);
      clients.delete(res);
      if (clients.size === 0 && watcher) {
        watcher.close();
        watcher = null;
      }
    };
    req.on('close', cleanup);
  }

  function close() {
    for (const res of clients) {
      try { res.end(); } catch { /* already gone */ }
    }
    clients.clear();
    if (watcher) { watcher.close(); watcher = null; }
  }

  return { addClient, close };
}

// ---------------------------------------------------------------------------
// createDashboardServer
// ---------------------------------------------------------------------------

/**
 * Create (but do not start) a dashboard HTTP server.
 *
 * @param {object} opts
 *   @param {string}  opts.meshRoot  absolute path to the mesh root
 *   @param {number}  [opts.port]    TCP port (0 = OS-assigned ephemeral)
 *   @param {string}  [opts.token]   auth token (generated if omitted)
 * @returns {{ start(): Promise<void>, close(): Promise<void>, url: string, token: string }}
 */
/**
 * Read a persisted dashboard token from `<meshRoot>/.agent-mesh/dashboard-token`
 * if present and well-formed; otherwise generate a fresh 32-byte hex token,
 * persist it with 0600 perms, and return it.
 *
 * This keeps old browser tabs / saved URLs valid across `agent-mesh dashboard`
 * restarts — without it every restart silently invalidates the cookie and the
 * UI shows 403s on `/api/agent/...` calls (page renders, but detail/list
 * endpoints fail authentication).
 */
function loadOrCreatePersistedToken(meshRoot) {
  const dir = join(meshRoot, '.agent-mesh');
  const file = join(dir, 'dashboard-token');
  try {
    const existing = readFileSync(file, 'utf8').trim();
    if (/^[a-f0-9]{64}$/i.test(existing)) return existing;
  } catch { /* missing or unreadable → fall through to generate */ }
  const fresh = randomBytes(32).toString('hex');
  try {
    mkdirSync(dir, { recursive: true });
    writeFileSync(file, fresh + '\n', { mode: 0o600 });
    chmodSync(file, 0o600);  // belt-and-suspenders: enforce even if umask masked it
  } catch (e) {
    // Persistence is best-effort. If the FS is read-only or sandboxed, fall
    // back to the old behaviour: a working but per-run token.
    process.stderr.write(`dashboard: could not persist auth token to ${file}: ${e.message}\n`);
  }
  return fresh;
}

export function createDashboardServer({ meshRoot, port = 7077, token, consoleBroker, watchPollMs = 1000, allowShell = false, chat = false, shellLauncher, sessionRunner, sessionIndex, sessionMirror, imgFetcher }) {
  // Resolve auth token. Precedence:
  //   1. Explicit `token` arg (tests inject deterministic tokens)
  //   2. Persisted token at <meshRoot>/.agent-mesh/dashboard-token (so a CLI
  //      restart reuses the same token — old browser tabs / saved URLs keep
  //      working instead of silently 403'ing)
  //   3. Fresh random 32-byte hex, persisted to that path with 0600
  const authToken = token ?? loadOrCreatePersistedToken(meshRoot);
  let resolvedPort = port;
  let server = null;

  // In-dashboard chat (the ask-only A2A console composer and the native-session
  // input) is OFF by default — the dashboard is a read-only monitor and Claude is
  // driven from the external CLI. When an explicit consoleBroker is injected (tests
  // that exercise the console route) chat is implicitly enabled. Read-only surfaces
  // (board, tree, activity, session-log transcript/stream) are unaffected.
  const chatEnabled = !!(chat || consoleBroker);

  // The Desk console broker (ask-only A2A). Injectable for tests; defaults to a
  // real broker bound to this mesh root.
  const broker = consoleBroker ?? createConsoleBroker({ meshRoot });

  // SSE hub for /api/events change notifications.
  const sse = createSseHub({ meshRoot, pollMs: watchPollMs });

  // Live mirror SSE responses (/session/:id/stream). Tracked so close() can end
  // them promptly — an active streaming response otherwise holds httpServer.close()
  // open until the keep-alive timeout.
  const mirrorStreams = new Set();

  // Native CLI launcher — only when explicitly enabled (privileged). Injectable
  // for tests; otherwise built when allowShell is set.
  const launcher = shellLauncher ?? (allowShell ? createShellLauncher({ meshRoot }) : null);

  // Dashboard-native session runner — only when explicitly enabled (privileged).
  // Injectable for tests; otherwise built when allowShell is set.
  const runner = sessionRunner ?? (allowShell ? createSessionRunner({ meshRoot }) : null);

  // Session-log index (list/transcript over CLI + dashboard transcripts) and the
  // read-only mirror. Injectable for tests; otherwise built when allowShell is set.
  const indexApi = sessionIndex ?? (allowShell
    ? {
        listSessions: (root) => defaultListSessions(root, { meshRoot }),
        resolveTranscript: (root, id) => defaultResolveTranscript(root, id, { meshRoot }),
        recordEvent: (mr, ev) => defaultRecordEvent(mr, ev),
        deleteSession: (root, id) => defaultDeleteSession(root, id, { meshRoot }),
        setLabel: (mr, id, name) => defaultSetLabel(mr, id, name),
        deleteLabel: (mr, id) => defaultDeleteLabel(mr, id),
        readLabels: (mr) => defaultReadLabels(mr)
      }
    : null);
  const mirror = sessionMirror ?? (allowShell ? createSessionMirror({}) : null);

  // The session-log surface is live whenever any of its backends exist.
  const sessionLogEnabled = !!(allowShell || runner || indexApi || mirror);

  // Image proxy fetcher — injectable for tests; when allowShell is set and no
  // injected fetcher, build the real SSRF-hardened one bound to fetchRemoteImage.
  const fetchImage = imgFetcher ?? (allowShell
    ? (url) => fetchRemoteImage(url, {
        allowHosts: ['covers.openlibrary.org', 'images-na.ssl-images-amazon.com'],
        maxBytes: 5_000_000,
        timeoutMs: 5000,
        maxRedirects: 2,
        fetchImpl: defaultPinnedFetch   // lookup defaults to dns.lookup(all) inside img-proxy
      })
    : null);

  const httpServer = createServer((req, res) => {
    handleRequest(req, res, {
      meshRoot,
      token: authToken,
      listenerPort: resolvedPort,
      consoleBroker: broker,
      chatEnabled,
      sse,
      shellLauncher: launcher,
      sessionRunner: runner,
      sessionIndex: indexApi,
      sessionMirror: mirror,
      sessionLogEnabled,
      fetchImage,
      mirrorStreams
    }).catch((err) => {
      applySecurityHeaders(res);
      try {
        sendText(res, 500, `Internal error: ${err.message}`);
      } catch { /* response already started */ }
    });
  });

  const start = () =>
    new Promise((resolve_, reject) => {
      httpServer.listen(port, '127.0.0.1', () => {
        const addr = httpServer.address();
        resolvedPort = addr.port;
        resolve_();
      });
      httpServer.once('error', reject);
    });

  const close = () =>
    new Promise((resolve_, reject) => {
      // End SSE streams first: their open sockets would otherwise block
      // httpServer.close() from ever completing. This covers both the /api/events
      // hub and the live-mirror /session/:id/stream responses.
      sse.close();
      for (const r of mirrorStreams) { try { r.end(); } catch { /* already gone */ } }
      mirrorStreams.clear();
      // Free any remaining tailer state (ring buffers); watchers/intervals are
      // already released by pauseTail when the last subscriber leaves, but this
      // makes teardown explicit and complete.
      mirror?.close?.();
      const finish = () => { broker.close().catch(() => {}).then(resolve_); };
      if (!httpServer.listening) { finish(); return; }
      httpServer.close((err) => {
        if (err) reject(err);
        else finish();
      });
    });

  // url is a getter so it returns the correct port after start()
  return {
    start,
    close,
    get url() {
      return `http://127.0.0.1:${resolvedPort}`;
    },
    get token() {
      return authToken;
    },
    get bootstrapUrl() {
      return `http://127.0.0.1:${resolvedPort}/?t=${authToken}`;
    }
  };
}
