/**
 * src/a2a/peer-bridge.js
 *
 * The framework-owned **peer bridge** (shell) — the single sanctioned
 * worker-visible MCP delegation surface (PROJECT.md §1.6 carve-out).
 *
 * A headless `claude -p` worker can only act through tools, so to let a worker
 * delegate onward it is handed ONE framework MCP server exposing generic verbs:
 *   - list_peers()                              → the agent's marked peers
 *   - delegate_to_peer({ peer, mode, task })    → A2A SendMessage to that peer
 *
 * The peer is named as DATA (an argument), never registered as a per-peer tool —
 * so this does not commit the "agent-as-MCP-tool is a category error" mistake.
 * The worker→bridge hop is local MCP; the bridge→peer hop is real A2A over
 * `createA2AClient`. v1 is ASK-ONLY: any non-`ask` onward call is refused with
 * `mode_disabled` before a peer is spawned (a capability gate, distinct from the
 * `readonly_parent` laundering code).
 */

import { randomUUID } from 'node:crypto';

import { readManagedRegistry } from './registry.js';
import { createA2AClient } from './stdio-client.js';
import { StdioTransport, rpcError } from '../mcp.js';
import { mcpTextResult } from '../contract.js';
import { MAX_TASK_CHARS } from '../config.js';

export const RESERVED_PREFIX = 'agentmesh_';
export const BRIDGE_SERVER_NAME = `${RESERVED_PREFIX}peerbridge`;

// Env keys the operator-authored registry `peer.env` must NOT override for a
// bridge spawn. PATH/DEPTH are already protected by stdio-client's PROTECTED_ENV;
// these add the rest of the security-relevant set (mode, mesh layer, ceiling).
export const RESERVED_BRIDGE_ENV = [
  'AGENT_MESH_MODE',
  'AGENT_MESH_MESH_ROOT',
  'AGENT_MESH_MESH_CEILING'
];

const ONWARD_MODE = 'ask'; // v1: ask-only

// ---------------------------------------------------------------------------
// Bridge core (testable without stdio)
// ---------------------------------------------------------------------------

/**
 * @param {object} opts
 *   @param {string} opts.root            agent root (holds registry.json)
 *   @param {object} [opts.env]           bridge process env (set by delegate.js)
 *   @param {Function} [opts.createClient] injectable A2A client factory (tests)
 *   @param {number} [opts.requestTimeoutMs]
 */
export function createBridge({ root, env = process.env, createClient = createA2AClient, requestTimeoutMs } = {}) {
  async function listPeers() {
    const { registry } = await readManagedRegistry(root);
    return Object.keys(registry.peers).map((name) => ({ name }));
  }

  /**
   * @returns {Promise<object>} a plain result object (mapped to an MCP text
   *   result by the server). Failures are DATA, never thrown.
   */
  async function delegateToPeer({ peer, mode = ONWARD_MODE, task } = {}) {
    // v1 ask-only capability gate — refuse BEFORE any spawn.
    if (mode !== ONWARD_MODE) {
      return refusal('mode_disabled',
        `Onward delegation is ask-only in v1; mode "${mode}" is disabled.`, peer);
    }
    if (typeof peer !== 'string' || peer.length === 0) {
      return refusal('bad_input', 'peer name is required.', peer);
    }
    if (typeof task !== 'string' || task.trim().length < 1) {
      return refusal('bad_input', 'task text is required.', peer);
    }
    if (task.length > MAX_TASK_CHARS) {
      return refusal('bad_input', `task exceeds the ${MAX_TASK_CHARS}-character limit.`, peer);
    }

    // Registry is the ONLY peer source — marker-validated.
    const managed = await readManagedRegistry(root);
    if (!managed.ok) {
      return refusal('bad_input',
        `no managed registry (${managed.reason}); the bridge offers no peers.`, peer);
    }
    if (!managed.registry.peers[peer]) {
      return refusal('bad_input', `peer "${peer}" is not in this agent's registry.`, peer);
    }

    let client;
    try {
      client = await createClient(managed.registry, {
        env,
        protectedEnv: RESERVED_BRIDGE_ENV,
        requestTimeoutMs
      });
    } catch (err) {
      return refusal('spawn_failed', `failed to spawn peer "${peer}": ${err.message}`, peer);
    }

    try {
      // Stamp the caller's run id (inherited from the worker env) so the peer's
      // start log records parentRunId → enables deterministic board edge
      // correlation. Framework-set metadata, never model-emitted.
      const parentRunId = env?.AGENT_MESH_RUN_ID;
      const metadata = { 'agentmesh/mode': ONWARD_MODE };
      if (parentRunId) metadata['agentmesh/parent_run_id'] = parentRunId;
      const message = {
        messageId: randomUUID(),
        role: 'ROLE_USER',
        parts: [{ text: task }],
        metadata
      };
      const taskResult = await client.send(peer, message);
      return mapTask(peer, taskResult);
    } catch (err) {
      return refusal('spawn_failed', err.message, peer);
    } finally {
      await client.close().catch(() => {});
    }
  }

  return { listPeers, delegateToPeer };
}

function refusal(errorCode, message, peer) {
  return {
    ok: false,
    peer: peer ?? null,
    status: 'rejected',
    error_code: errorCode,
    summary: message,
    log_path: ''
  };
}

// Map a downstream A2A Task into the bridge tool result, PRESERVING the
// structured audit fields (status, error_code, log_path) so a peer failure is
// not silently flattened (R1/MAJOR-6).
//
// The MCP-facing tool surface keeps the lowercase status names ('completed',
// 'rejected', ...); only the incoming A2A v1.0 TaskState enum parsing changed.
function normalizeTaskState(state) {
  if (typeof state !== 'string' || !state.startsWith('TASK_STATE_')) return 'unknown';
  return state.slice('TASK_STATE_'.length).toLowerCase().replace(/_/g, '-');
}

function mapTask(peer, task) {
  const md = task?.metadata ?? {};
  const rawState = task?.status?.state;
  const state = normalizeTaskState(rawState);
  const artifactText = (task?.artifacts ?? [])
    .flatMap((a) => (Array.isArray(a.parts) ? a.parts : []))
    // v1.0 parts are discriminated by member name: text part = { text }.
    .filter((p) => p && typeof p.text === 'string')
    .map((p) => p.text)
    .join('\n\n');
  const statusText = (task?.status?.message?.parts ?? [])
    .filter((p) => p && typeof p.text === 'string')
    .map((p) => p.text)
    .join('\n');
  return {
    ok: rawState === 'TASK_STATE_COMPLETED',
    peer,
    status: state,
    error_code: md['agentmesh/error_code'] ?? null,
    files_changed: md['agentmesh/files_changed'] ?? null,
    log_path: md['agentmesh/log_path'] ?? '',
    summary: artifactText || statusText || ''
  };
}

// ---------------------------------------------------------------------------
// Stdio MCP server wrapper
// ---------------------------------------------------------------------------

export function createPeerBridgeServer({ root, env = process.env }) {
  const bridge = createBridge({ root, env });

  return {
    async start(input, output) {
      const transport = new StdioTransport(input, output, async (message) => {
        const response = await handle(message, bridge);
        if (response) transport.send(response);
      });
      transport.start();
      await new Promise((resolve) => input.on('end', resolve));
    }
  };
}

async function handle(message, bridge) {
  if (!message || typeof message !== 'object') return null;
  const { id, method, params } = message;

  if (method === 'initialize') {
    return {
      jsonrpc: '2.0',
      id,
      result: {
        protocolVersion: params?.protocolVersion || '2024-11-05',
        capabilities: { tools: {} },
        serverInfo: { name: BRIDGE_SERVER_NAME, version: '0.1.0' }
      }
    };
  }

  if (method === 'ping') return { jsonrpc: '2.0', id, result: {} };

  if (method === 'tools/list') {
    return { jsonrpc: '2.0', id, result: { tools: buildTools() } };
  }

  if (method === 'tools/call') {
    const name = params?.name;
    const args = params?.arguments || {};
    if (name === 'list_peers') {
      return { jsonrpc: '2.0', id, result: mcpTextResult(await bridge.listPeers()) };
    }
    if (name === 'delegate_to_peer') {
      return { jsonrpc: '2.0', id, result: mcpTextResult(await bridge.delegateToPeer(args)) };
    }
    return rpcError(id, -32602, `Unknown tool: ${name}`);
  }

  if (id === undefined) return null;
  return rpcError(id, -32601, `Unknown method: ${method}`);
}

function buildTools() {
  return [
    {
      name: 'list_peers',
      description:
        'List the peer agents this agent may delegate to (from its managed registry). ' +
        'Returns [{ name }]. Use delegate_to_peer to send one a scoped task.',
      inputSchema: { type: 'object', additionalProperties: false, properties: {} }
    },
    {
      name: 'delegate_to_peer',
      description:
        'Delegate a scoped task to a named peer agent over A2A and return its final result. ' +
        'v1 is ask-only (read/answer tasks); "mode" must be "ask".',
      inputSchema: {
        type: 'object',
        additionalProperties: false,
        required: ['peer', 'task'],
        properties: {
          peer: { type: 'string', minLength: 1 },
          mode: { type: 'string', enum: ['ask'] },
          task: { type: 'string', minLength: 1, maxLength: MAX_TASK_CHARS }
        }
      }
    }
  ];
}
