import { readFile, readdir, access } from 'node:fs/promises';
import { join } from 'node:path';
import { MAX_LINE_CHARS } from '../config.js';
import { delegateTask } from '../delegate.js';
import { fastPathExecute } from '../fast-path.js';
import { orchestrate } from '../orchestrator.js';
import { describeFolder } from '../description.js';
import { SerialQueue } from '../lock.js';
import { loadSnapshot, checkConformance } from '../builder/conformance.js';
import {
  A2A_PROTOCOL_VERSION,
  buildAgentCard,
  buildRejectedTask,
  buildTaskFromDelegateResult,
  rpcError,
  rpcResult,
  validateMessageSendParams
} from './protocol.js';

/**
 * Read the agent.json x-agentmesh.modes from the agent's folder.
 * Returns an array of strings when declared, or null when absent/unreadable.
 */
async function readAgentModes(root) {
  try {
    const raw = await readFile(join(root, 'agent.json'), 'utf8');
    const agentJson = JSON.parse(raw);
    const modes = agentJson?.['x-agentmesh']?.modes;
    if (Array.isArray(modes) && modes.length > 0) return modes;
    return null;
  } catch {
    return null;
  }
}

export async function createA2AStdioServer({ root, env, strict = false }) {
  const self = await describeFolder(root);
  const doQueue = new SerialQueue();

  // Read agent.json modes once at startup (capability gate)
  const agentModes = await readAgentModes(root);
  // describeFolder() (self) carries name/description/capabilities from AGENT.md;
  // role/primaryTool live in agent.json's x-agentmesh, so read that and merge it
  // in so the card advertises them (orchestrator discovery + fast-path).
  let agentXa = null;
  try {
    agentXa = JSON.parse(await readFile(join(root, 'agent.json'), 'utf8'))?.['x-agentmesh'] ?? null;
  } catch { /* no agent.json */ }
  const cardSelf = agentXa ? { ...self, 'x-agentmesh': agentXa } : self;
  const card = buildAgentCard({ self: cardSelf, root, url: `stdio:${root}`, modes: agentModes });
  // Orchestrator role (read once): when set, an incoming task is routed
  // (rules → LLM fallback) to a peer fast-path/delegation instead of a heavy loop.
  const agentRole = card['x-agentmesh']?.role ?? null;

  // Startup self-check: run conformance on own root. Warn by default; refuse under --strict.
  await runSelfCheck(root, strict);

  return {
    async start(input, output) {
      const transport = new NdjsonTransport(input, output, async (message) => {
        const response = await handleMessage({
          message,
          root,
          env,
          card,
          doQueue,
          agentModes,
          agentRole
        });
        if (response) transport.send(response);
      });
      transport.start();
      await new Promise((resolve) => input.on('end', resolve));
    }
  };
}

/**
 * Run conformance check on the served root (startup self-check).
 * Logs warnings to stderr on any fail/warn.
 * Under strict mode, throws if there are any fails (so the caller can exit non-zero).
 * In default (non-strict) mode, any unexpected error is swallowed so startup is never blocked.
 */
async function runSelfCheck(root, strict) {
  let snapshot;
  try {
    snapshot = await buildStandaloneSnapshot(root);
  } catch {
    // Can't build snapshot — skip self-check in default mode; in strict mode still skip
    // (we can't fail-safe without a snapshot) and log a warning.
    process.stderr.write('[agent-mesh] serve-a2a: could not run startup self-check.\n');
    return;
  }

  let report;
  try {
    report = checkConformance(snapshot);
  } catch {
    process.stderr.write('[agent-mesh] serve-a2a: conformance check threw unexpectedly.\n');
    return;
  }

  const hasFail = report.rules.some(r => r.level === 'fail');
  const hasWarn = report.rules.some(r => r.level === 'warn');

  if (hasFail || hasWarn) {
    const lines = ['[agent-mesh] serve-a2a conformance warning:'];
    for (const r of report.rules) {
      if (r.level === 'fail' || r.level === 'warn') {
        lines.push(`  [${r.level.toUpperCase()}] ${r.rule}: ${r.detail}`);
      }
    }
    process.stderr.write(lines.join('\n') + '\n');
  }

  if (strict && hasFail) {
    throw new Error(
      'serve-a2a --strict: conformance failures detected. Fix them or remove --strict to warn-and-serve.'
    );
  }
}

/**
 * Build a minimal snapshot for standalone conformance self-check.
 * Treats the root as both the mesh root and the single-agent folder,
 * using a synthetic manifest entry so checkConformance can run its per-agent rules.
 */
async function buildStandaloneSnapshot(root) {
  // Build a minimal per-agent snapshot for the served root so checkConformance
  // can run anatomy/tools/card/standalone-runnable/version rules standalone.
  // Does NOT require a mesh.json (manifest is set to null).
  const agentName = root.split(/[/\\]/).at(-1) || 'agent';

  // agent.json
  let agentJson = null;
  let agentJsonError = null;
  try {
    agentJson = JSON.parse(await readFile(join(root, 'agent.json'), 'utf8'));
  } catch (err) {
    agentJsonError = err.code === 'ENOENT' ? null : err.message;
  }

  // prompts/system.md
  let systemMdExists = false;
  let systemMdContent = null;
  try {
    systemMdContent = await readFile(join(root, 'prompts', 'system.md'), 'utf8');
    systemMdExists = true;
  } catch { /* absent */ }

  // .mcp.json
  let mcpJson = null;
  try {
    mcpJson = JSON.parse(await readFile(join(root, '.mcp.json'), 'utf8'));
  } catch { /* absent */ }

  // tools/*/server.mjs
  const toolServers = [];
  try {
    const entries = await readdir(join(root, 'tools'), { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const serverPath = join(root, 'tools', entry.name, 'server.mjs');
      try { await access(serverPath); toolServers.push(`tools/${entry.name}/server.mjs`); } catch { /* absent */ }
    }
  } catch { /* no tools dir */ }

  // registry.json
  let registryJson = null;
  let registryMarker = null;
  try {
    const raw = await readFile(join(root, 'registry.json'), 'utf8');
    registryJson = JSON.parse(raw);
    registryMarker = registryJson['x-agentmesh-generated'] === true;
  } catch { /* absent */ }

  // Other prompt files
  const generatedPrompts = [];
  for (const relPath of ['prompts/ask.md', 'prompts/do.md']) {
    try {
      const content = await readFile(join(root, relPath), 'utf8');
      generatedPrompts.push({ path: relPath, content });
    } catch { /* absent */ }
  }

  const agentSnapshot = {
    name: agentName,
    root: '.',
    // served:false in standalone snapshot so the enabled-modes rule
    // (served:true → non-empty enabledModes) does not fire for standalone agents
    // that have no mesh policy applied yet.
    served: false,
    enabledModes: [],
    peers: [],
    agentRoot: root,
    agentRootCanonical: root,
    agentJson,
    agentJsonError,
    systemMdExists,
    systemMdContent,
    generatedPrompts,
    mcpJson,
    mcpJsonError: null,
    toolServers,
    registryJson,
    registryMarker
  };

  return {
    meshRoot: root,
    manifest: null,
    manifestError: 'standalone — no mesh.json',
    agents: [agentSnapshot],
    expectedRegistries: null
  };
}

async function handleMessage({ message, root, env, card, doQueue, agentModes, agentRole }) {
  if (!message || typeof message !== 'object' || Array.isArray(message)) {
    return rpcError(null, -32600, 'Invalid JSON-RPC request.');
  }

  const { id, method, params } = message;
  if (message.jsonrpc !== '2.0' || typeof method !== 'string') {
    return rpcError(id ?? null, -32600, 'Invalid JSON-RPC request.');
  }

  // A JSON-RPC notification (no id) gets no response and must not trigger a
  // side effect. None of this server's methods are defined as notifications, so
  // a notification for any of them — including SendMessage, which would
  // otherwise spawn an unrequested worker — is dropped before dispatch.
  if (id === undefined) return null;

  if (method === 'initialize') {
    return rpcResult(id, {
      protocolVersion: A2A_PROTOCOL_VERSION,
      agentCard: card,
      capabilities: {}
    });
  }

  if (method === 'ping') {
    return rpcResult(id, {});
  }

  // A2A v1.0 method name. The legacy v0.3.0 `message/send` is NOT aliased — it
  // falls through to the unknown-method JSON-RPC error below.
  if (method === 'SendMessage') {
    const validation = validateMessageSendParams(params);
    if (!validation.ok) {
      // SendMessageResponse is a oneof — the Task is wrapped as { task }.
      return rpcResult(id, {
        task: buildRejectedTask({
          code: 'bad_input',
          message: validation.message,
          requestMessage: params?.message
        })
      });
    }

    const requestedMode = validation.value.input.mode;

    // Layer 1: Capability gate — always enforced when agent.json declares modes.
    if (agentModes !== null && !agentModes.includes(requestedMode)) {
      return rpcResult(id, {
        task: buildRejectedTask({
          code: 'mode_disabled',
          message: `Mode "${requestedMode}" is not in this agent's declared capabilities [${agentModes.join(', ')}].`,
          requestMessage: params?.message
        })
      });
    }

    // Layer 2: Policy gate — only when AGENT_MESH_ENABLED_MODES is present in env.
    const enabledModesEnv = (env || {})['AGENT_MESH_ENABLED_MODES'];
    if (enabledModesEnv !== undefined) {
      const policyModes = enabledModesEnv
        .split(',')
        .map(m => m.trim())
        .filter(m => m.length > 0);
      if (!policyModes.includes(requestedMode)) {
        return rpcResult(id, {
          task: buildRejectedTask({
            code: 'mode_disabled',
            message: `Mode "${requestedMode}" is not enabled by mesh policy (AGENT_MESH_ENABLED_MODES="${enabledModesEnv}").`,
            requestMessage: params?.message
          })
        });
      }
    }

    const started = process.hrtime.bigint();
    // Board correlation: a caller (peer bridge / orchestrator) stamps its run id
    // as agentmesh/parent_run_id; record it so this child's start log links back.
    const parentRunId = validation.value.metadata?.['agentmesh/parent_run_id'] ?? null;
    // Deterministic primary-tool fast-path: a framework-set agentmesh/toolCall
    // runs the declared primaryTool directly (no claude -p). Undeclared/mismatched
    // toolCall → mode_disabled inside the executor. Absent → normal delegation.
    const toolCall = validation.value.metadata?.['agentmesh/toolCall'];
    const run = toolCall
      ? () => fastPathExecute({ root, env, toolCall, task: validation.value.input.task, parentRunId })
      : agentRole === 'orchestrator'
        ? () => orchestrate({ root, env, input: validation.value.input, parentRunId })
        : () => delegateTask({ root, env, input: validation.value.input, parentRunId });
    const result =
      validation.value.input.mode === 'do'
        ? await runSerialized({ queue: doQueue, run, started })
        : await runWithMetrics({ run, started, queueWaitMs: 0 });

    return rpcResult(id, {
      task: buildTaskFromDelegateResult({
        result: result.result,
        message: validation.value.message,
        metrics: result.metrics
      })
    });
  }

  return rpcError(id, -32601, `Unknown method: ${method}`);
}

async function runSerialized({ queue, run, started }) {
  const queuedAt = process.hrtime.bigint();
  return queue.run(async () => {
    const queueWaitMs = elapsedMs(queuedAt);
    return runWithMetrics({ run, started, queueWaitMs });
  });
}

async function runWithMetrics({ run, started, queueWaitMs }) {
  const workerStarted = process.hrtime.bigint();
  const result = await run();
  return {
    result,
    metrics: {
      queue_wait_ms: queueWaitMs,
      worker_spawn_ms: 0,
      worker_run_ms: elapsedMs(workerStarted),
      change_detect_ms: 0,
      total_ms: elapsedMs(started),
      isolation_violations: 0,
      recursion_refusals: result?.status === 'refused' ? { [result.error?.code || 'internal']: 1 } : {},
      conformance: 'not_run'
    }
  };
}

function elapsedMs(start) {
  // Convert to Number BEFORE dividing — BigInt division truncates toward zero,
  // which would zero out every sub-millisecond duration and drop fractional ms.
  return Number(process.hrtime.bigint() - start) / 1e6;
}

class NdjsonTransport {
  constructor(input, output, onMessage) {
    this.input = input;
    this.output = output;
    this.onMessage = onMessage;
    this.buffer = '';
  }

  start() {
    // setEncoding holds back partial multi-byte UTF-8 sequences across chunk
    // boundaries (StringDecoder), so a non-ASCII char split between two stdin
    // chunks is not corrupted into U+FFFD. Per-chunk chunk.toString('utf8')
    // would decode each half independently and lose the character.
    this.input.setEncoding('utf8');
    this.input.on('data', (chunk) => {
      this.buffer += chunk;
      // Bound pre-parse buffering: a frame with no newline that exceeds the cap
      // is dropped (and reported) rather than grown without limit.
      if (this.buffer.length > MAX_LINE_CHARS && this.buffer.indexOf('\n') === -1) {
        this.buffer = '';
        this.send(rpcError(null, -32700, 'Frame exceeds maximum length.'));
        return;
      }
      this.drain();
    });
  }

  send(message) {
    this.output.write(`${JSON.stringify(message)}\n`);
  }

  drain() {
    let newline = this.buffer.indexOf('\n');
    while (newline !== -1) {
      const line = this.buffer.slice(0, newline).trim();
      this.buffer = this.buffer.slice(newline + 1);
      if (line) this.dispatch(line);
      newline = this.buffer.indexOf('\n');
    }
  }

  dispatch(line) {
    let message;
    try {
      message = JSON.parse(line);
    } catch {
      this.send(rpcError(null, -32700, 'Parse error.'));
      return;
    }

    this.onMessage(message).catch((error) => {
      const id = message && typeof message === 'object' ? message.id : null;
      this.send(rpcError(id ?? null, -32603, error.message));
    });
  }
}
