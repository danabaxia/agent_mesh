import { readdir, stat } from 'node:fs/promises';
import { join } from 'node:path';
import {
  DEFAULT_DEPTH,
  DEFAULT_TIMEOUT_MS,
  WRITE_TOOLS,
  readPositiveInt
} from './config.js';
import { readLayer } from './settings-merge.js';
import { validateDelegateInput } from './contract.js';
import { enterCallContext } from './context.js';
import { captureChangeState, computeFilesChanged } from './change-detect.js';
import { badInput, refused, resultError } from './errors.js';
import { createRunLog, appendRunLog } from './log.js';
import { spawnFile } from './process.js';
import {
  buildClaudeInvocation, buildClaudeEnv, compactArgv
} from './delegate-invocation.js';

export { resolveMeshRoot } from './delegate-invocation.js';

// Managed-settings paths inspected by the preflight. Each entry is a candidate
// JSON file or directory; presence is best-effort (missing → skipped).
const MANAGED_PATHS_BY_PLATFORM = {
  darwin: [
    '/Library/Application Support/ClaudeCode/managed-settings.json',
    '/Library/Application Support/ClaudeCode/managed-settings.d',
  ],
  linux: [
    '/etc/claude-code/managed-settings.json',
    '/etc/claude-code/managed-settings.d',
  ],
};

function managedPathsFor(env, platform) {
  const override = env?.AGENT_MESH_TEST_MANAGED_FILE;
  if (override) return [override];
  return MANAGED_PATHS_BY_PLATFORM[platform] || [];
}

async function inspectManagedPolicyDocs(env, platform) {
  const docs = [];
  for (const p of managedPathsFor(env, platform)) {
    try {
      const s = await stat(p);
      if (s.isFile()) {
        const r = await readLayer(p);
        if (r.ok) docs.push(r.value);
      } else if (s.isDirectory()) {
        const files = await readdir(p);
        for (const f of files.sort()) {
          if (!f.endsWith('.json')) continue;
          const r = await readLayer(join(p, f));
          if (r.ok) docs.push(r.value);
        }
      }
    } catch { /* missing or unreadable → skip silently */ }
  }
  return docs;
}

function managedPolicyBlocksMeshHook(doc) {
  if (doc?.disableAllHooks === true) return 'disableAllHooks';
  if (doc?.allowManagedHooksOnly === true) return 'allowManagedHooksOnly';
  const entries = doc?.hooks?.PreToolUse;
  if (Array.isArray(entries)) {
    for (const e of entries) {
      const m = String(e?.matcher || '');
      if (WRITE_TOOLS.some((t) => m.includes(t))) return 'overlapping_PreToolUse';
    }
  }
  return null;
}

async function preflightManagedPolicy(env, platform) {
  if (platform === 'win32') {
    if (env?.AGENT_MESH_ATTEST_MANAGED_COMPATIBLE === '1') return null;
    return {
      reason: 'managed_policy_unverifiable_windows',
      message:
        'Windows managed-settings introspection is incomplete in v1; set AGENT_MESH_ATTEST_MANAGED_COMPATIBLE=1 to attest compatibility.',
    };
  }
  const docs = await inspectManagedPolicyDocs(env, platform);
  for (const d of docs) {
    const block = managedPolicyBlocksMeshHook(d);
    if (block) {
      return {
        reason: 'incompatible_managed_policy',
        message: `Managed policy ${block} would prevent the mesh path-guard from running.`,
      };
    }
  }
  return null;
}

export async function delegateTask({ root, env, input, parentRunId = null, route = null }) {
  const validation = validateDelegateInput(input);
  if (!validation.ok) return badInput(validation.message);

  const { mode, task } = validation.value;
  if (env.AGENT_MESH_MODE === 'ask' && mode === 'do') {
    return refused('readonly_parent', 'Refusing write delegation from a read-only parent task.');
  }

  const entered = enterCallContext(root, env, DEFAULT_DEPTH);
  if (!entered.ok) return entered.result;

  // do-mode preflight: refuse if OS-level managed settings would silently
  // disable the mesh's path-guard PreToolUse hook. ask is unaffected because
  // it has no hook to be disabled. See docs/.../settings-inheritance-design.md.
  if (mode === 'do') {
    const platform = env.AGENT_MESH_TEST_PLATFORM || process.platform;
    const blocked = await preflightManagedPolicy(env, platform);
    if (blocked) return refused(blocked.reason, blocked.message);
  }

  // Grouped per-date log file + a unique run id (start + final share it). The
  // log dir is excluded from change detection, so these records never affect
  // files_changed / preexisting_dirty.
  const { logPath, runId } = await createRunLog(root, env);
  const startedAt = new Date().toISOString();
  // START record (state:"started", no finished_at) so the dashboard can show the
  // agent as "working" mid-task; a FINAL record with the same id is appended at
  // completion (readers dedup by id, last wins).
  await appendRunLog(logPath, {
    id: runId, parent_run_id: parentRunId, route,
    started_at: startedAt, root, mode, task, state: 'started'
  });

  const timeoutMs = readPositiveInt(env.AGENT_MESH_TIMEOUT_MS, DEFAULT_TIMEOUT_MS);
  const before = await captureChangeState(root);

  let spawnResult;
  let invocation;
  try {
    const claudeEnv = buildClaudeEnv({ root, env, mode, callEnv: entered.env, runId });
    invocation = await buildClaudeInvocation({ root, mode, task, env, callEnv: entered.env, claudeEnv });
    spawnResult = await spawnFile(env.AGENT_MESH_CLAUDE || 'claude', invocation.args, {
      cwd: root,
      env: claudeEnv,
      timeoutMs,
      detached: true
    });
  } catch (error) {
    const result = resultError('spawn_failed', error.message);
    result.log_path = logPath;
    result.run_id = runId;
    await appendRunLog(logPath, {
      id: runId,
      parent_run_id: parentRunId,
      route,
      started_at: startedAt,
      finished_at: new Date().toISOString(),
      root,
      mode,
      task,
      state: 'done',
      status: result.status,
      result
    });
    return result;
  }

  const changed = await computeFilesChanged(root, before);
  const result = buildDelegateResult({ spawnResult, changed, logPath });
  result.run_id = runId;
  await appendRunLog(logPath, {
    id: runId,
    parent_run_id: parentRunId,
    route,
    started_at: startedAt,
    finished_at: new Date().toISOString(),
    root,
    mode,
    task,
    state: 'done',
    status: result.status,
    summary: result.summary,
    // Keep grouped-file lines compact + atomic: drop the huge system-prompt body
    // from argv and tail stdout/stderr.
    argv: compactArgv(invocation.args),
    stdout: tail(spawnResult.stdout, 2000),
    stderr: tail(spawnResult.stderr, 2000),
    result
  });
  return result;
}

// Env for the framework peer bridge MCP server. The bridge inherits the worker's
// (claude's) environment for system PATH etc.; here we set only the
// security-relevant overrides:
//   - AGENT_MESH_MODE='ask'  → v1 ask-only onward (overrides the worker's mode so
//     the bridge cannot launder a `do` worker into a `do` peer call).
//   - AGENT_MESH_PATH/DEPTH  → the THREADED call context (from entered.env) so
//     peers the bridge spawns get correct cycle/depth detection.
//   - framework config pass-through (mesh root/ceiling, claude binary, timeout,
//     log dir) so peers resolve the same global layer + ceiling.

function buildDelegateResult({ spawnResult, changed, logPath }) {
  const base = {
    summary: summarizeSpawn(spawnResult),
    files_changed: changed.files_changed,
    log_path: logPath
  };
  if (changed.preexisting_dirty) base.preexisting_dirty = true;
  if (changed.best_effort) base.best_effort = true;
  if (changed.note) base.note = changed.note;

  if (spawnResult.timedOut) {
    return {
      status: 'timeout',
      ...base
    };
  }

  if (spawnResult.error) {
    return {
      status: 'error',
      ...base,
      error: { code: 'spawn_failed', message: spawnResult.error.message }
    };
  }

  if (spawnResult.code !== 0) {
    return {
      status: 'error',
      ...base,
      error: {
        code: 'internal',
        message: spawnResult.stderr.trim() || `claude exited with code ${spawnResult.code}`
      }
    };
  }

  return {
    status: 'done',
    ...base
  };
}

function summarizeSpawn(spawnResult) {
  const text = (spawnResult.stdout || spawnResult.stderr || '').trim();
  if (spawnResult.timedOut) {
    return text ? `Timed out. Last output:\n${tail(text)}` : 'Timed out before producing output.';
  }
  return tail(text) || 'Completed without output.';
}

function tail(text, limit = 4000) {
  if (text.length <= limit) return text;
  return text.slice(text.length - limit);
}
