import { readFile, readdir, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { MAX_MEMORY_FILE_CHARS, MAX_PROMPT_CHARS } from './config.js';

// Spec §4 line 135: cap each extracted skill summary at 500 characters.
const MAX_SKILL_SUMMARY_CHARS = 500;

// Public: discover the agent's runtime anatomy without reading file contents.
// Returns a structure useful both for observability logs (§5 — what the
// runtime "saw") and for assembling the runtime prompt below.
//
// `meshRoot` is supplied by the caller. delegate.js resolves it via env →
// walk-up → null; here we just take it as given (null is a valid "no global
// layer" signal, in which case globalSkills is empty).
export async function discoverAgentStructure(root, { meshRoot } = {}) {
  const resolvedMeshRoot = meshRoot ?? null;
  return {
    root,
    meshRoot: resolvedMeshRoot,
    systemPromptPath: await pathIfExists(join(root, 'prompts', 'system.md')),
    modePromptPath: {
      ask: await pathIfExists(join(root, 'prompts', 'ask.md')),
      do: await pathIfExists(join(root, 'prompts', 'do.md'))
    },
    memoryFiles: await listMemoryFiles(root),
    workflowFiles: {
      default: await pathIfExists(join(root, 'workflows', 'default.md')),
      ask: await pathIfExists(join(root, 'workflows', 'ask.md')),
      do: await pathIfExists(join(root, 'workflows', 'do.md'))
    },
    globalSkills: resolvedMeshRoot
      ? await listSkills(join(resolvedMeshRoot, 'skills'))
      : [],
    localSkills: await listLocalSkills(root)
  };
}

// Public: assemble the worker's runtime system prompt per spec §4 lines
// 119-128. Assembly order:
//   1. prompts/system.md
//   2. memory/profile.md
//   3. other memory/*.md files, sorted by filename
//   4. workflows/default.md
//   5. workflows/<mode>.md
//   6. prompts/<mode>.md
//   7. global skill summaries from mesh/skills/*/SKILL.md
//   8. local skill summaries from skills/*/SKILL.md
//
// Missing files / dirs are silently skipped (§9 line 296 "Missing
// directories are ignored without failure"). Output is length-bounded by
// MAX_PROMPT_CHARS, matching the existing prompt budget in delegate.js.
// Returns null when the agent has no prompt material at all (preserves the
// "no --append-system-prompt" path in delegate.js for bare folders).
export async function buildAgentRuntimePrompt(root, mode, { meshRoot } = {}) {
  const structure = await discoverAgentStructure(root, { meshRoot });
  const sections = [];

  await pushFile(sections, structure.systemPromptPath);
  // Memory files are capped per-file so a single oversized one cannot consume
  // the whole budget and starve the mode prompt / skills that come after.
  for (const path of structure.memoryFiles) await pushFile(sections, path, MAX_MEMORY_FILE_CHARS);

  const decisionsIndex = await buildDecisionsIndex(root);
  if (decisionsIndex) sections.push(decisionsIndex);

  await pushFile(sections, structure.workflowFiles.default);
  await pushFile(sections, structure.workflowFiles[mode]);
  await pushFile(sections, structure.modePromptPath[mode]);

  const globalBlock = await renderSkillsBlock('Available global skills:', structure.globalSkills);
  if (globalBlock) sections.push(globalBlock);
  const localBlock = await renderSkillsBlock('Available local skills:', structure.localSkills);
  if (localBlock) sections.push(localBlock);

  if (sections.length === 0) return null;
  return bound(sections.join('\n\n'));
}

// Public (also exported for unit testing the algorithm directly):
// Extract a single-line summary from a SKILL.md per spec §4 lines 130-138.
//   1. use `name` and `description` frontmatter when both are present;
//   2. otherwise use the first non-empty paragraph after optional frontmatter;
//   3. cap the extracted summary at 500 characters.
export async function extractSkillSummary(path) {
  let text;
  try {
    text = await readFile(path, 'utf8');
  } catch {
    return '';
  }
  const { frontmatter, body } = splitFrontmatter(text);
  if (frontmatter) {
    const name = frontmatterValue(frontmatter, 'name');
    const description = frontmatterValue(frontmatter, 'description');
    if (name && description) return capSummary(description);
  }
  return capSummary(firstNonEmptyParagraph(body));
}

// ─── internals ─────────────────────────────────────────────────────────────

async function pathIfExists(path) {
  try {
    await stat(path);
    return path;
  } catch {
    return null;
  }
}

// Memory order per §4 lines 121-122: profile.md first, then the rest sorted
// by filename. decisions.md is excluded from eager loading.
async function listMemoryFiles(root) {
  const dir = join(root, 'memory');
  let entries;
  try {
    entries = await readdir(dir);
  } catch {
    return [];
  }
  const md = entries.filter((name) => name.endsWith('.md') && name !== 'decisions.md').sort();
  const profileFirst = md.includes('profile.md')
    ? ['profile.md', ...md.filter((name) => name !== 'profile.md')]
    : md;
  return profileFirst.map((name) => join(dir, name));
}

// Build a lightweight index of past decisions from decisions.md
async function buildDecisionsIndex(root) {
  const decisionsPath = join(root, 'memory', 'decisions.md');
  try {
    const text = await readFile(decisionsPath, 'utf8');
    const lines = text.split('\n');
    const indexLines = [];
    let currentBullet = null;

    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith('- ')) {
        if (currentBullet) {
          indexLines.push(currentBullet);
        }
        currentBullet = trimmed;
      } else if (trimmed === '' || trimmed.startsWith('#')) {
        // Skip headers or empty lines
      } else if (currentBullet) {
        currentBullet += ' ' + trimmed;
      }
    }
    if (currentBullet) {
      indexLines.push(currentBullet);
    }

    const formattedBullets = indexLines.map((bullet) => {
      const text = bullet.slice(2).trim();
      let summary = text;
      if (summary.length > 80) {
        summary = summary.slice(0, 77).trimEnd() + '...';
      }
      return `- ${summary} (use recall_decision)`;
    });

    if (formattedBullets.length > 0) {
      return `### System Decisions Index:\n${formattedBullets.join('\n')}`;
    }
  } catch {
    // decisions.md not present or unreadable; skip
  }
  return null;
}

// Local (per-agent) skill roots, searched in precedence order: the mesh-canonical
// `skills/` first, then Claude Code's `.claude/skills/`, then the `.agent/skills/`
// convention some projects use. This lets `agent-mesh add` convert an existing
// agent and have its skills discovered IN PLACE (no relocation) — `skills/` wins on
// a name collision. (Global mesh skills stay single-root under mesh/skills/.)
const LOCAL_SKILL_ROOTS = ['skills', join('.claude', 'skills'), join('.agent', 'skills')];

// Public: discover an agent's local skills across all supported skill-root
// conventions, de-duplicated by skill name (first root wins).
export async function listLocalSkills(root) {
  const byName = new Map();
  for (const rel of LOCAL_SKILL_ROOTS) {
    for (const skill of await listSkills(join(root, rel))) {
      if (!byName.has(skill.name)) byName.set(skill.name, skill);
    }
  }
  return [...byName.values()].sort((a, b) => a.name.localeCompare(b.name));
}

// A skill is a subdirectory of skills/ containing a SKILL.md.
// Sorted alphabetically by skill (subdir) name for deterministic output.
async function listSkills(skillsDir) {
  let entries;
  try {
    entries = await readdir(skillsDir, { withFileTypes: true });
  } catch {
    return [];
  }
  const skills = [];
  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const skillPath = join(skillsDir, entry.name, 'SKILL.md');
    if (await pathIfExists(skillPath)) {
      skills.push({ name: entry.name, path: skillPath });
    }
  }
  return skills.sort((a, b) => a.name.localeCompare(b.name));
}

async function pushFile(sections, path, maxChars) {
  if (!path) return;
  try {
    const text = await readFile(path, 'utf8');
    let trimmed = text.trim();
    if (!trimmed) return;
    if (maxChars && trimmed.length > maxChars) {
      trimmed = `${trimmed.slice(0, Math.max(0, maxChars - 15)).trimEnd()}... [truncated]`;
    }
    sections.push(trimmed);
  } catch {
    // missing or unreadable; silently skip
  }
}

// Renders the spec §6 observability block:
//   Available <scope> skills:
//   - <name>: <summary>
//   - ...
// Returns null when there are no skills, so the caller can drop the section.
async function renderSkillsBlock(heading, skills) {
  if (skills.length === 0) return null;
  const lines = [heading];
  for (const skill of skills) {
    const summary = await extractSkillSummary(skill.path);
    lines.push(`- ${skill.name}: ${summary}`);
  }
  return lines.join('\n');
}

// Minimal YAML frontmatter splitter — recognizes a leading `---` fenced
// block and returns the inner text plus the body after the closing fence.
// Intentionally narrow: we only need `name: value` and `description: value`
// extraction, not a full YAML parser. Anything more exotic falls through to
// the paragraph fallback.
function splitFrontmatter(text) {
  const stripped = text.replace(/^﻿/, '').replace(/\r\n/g, '\n');
  if (!stripped.startsWith('---')) return { frontmatter: null, body: stripped };
  // Find the closing fence at the start of a line.
  const closeMatch = stripped.slice(3).match(/\n---[ \t]*(\n|$)/);
  if (!closeMatch) return { frontmatter: null, body: stripped };
  const closeStart = 3 + closeMatch.index; // position of "\n---" in `stripped`
  const closeEnd = closeStart + closeMatch[0].length; // just past the trailing newline (or EOF)
  const frontmatter = stripped.slice(3, closeStart).replace(/^\n/, '');
  const body = stripped.slice(closeEnd);
  return { frontmatter, body };
}

function frontmatterValue(frontmatter, key) {
  const re = new RegExp(`^${escapeForRegex(key)}\\s*:\\s*(.+)$`, 'm');
  const match = frontmatter.match(re);
  if (!match) return null;
  let value = match[1].trim();
  if ((value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))) {
    value = value.slice(1, -1);
  }
  return value || null;
}

function escapeForRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function firstNonEmptyParagraph(body) {
  const paragraphs = body.split(/\n[ \t]*\n/);
  for (const p of paragraphs) {
    const collapsed = p.trim().replace(/\s+/g, ' ');
    if (collapsed) return collapsed;
  }
  return '';
}

function capSummary(text) {
  const trimmed = String(text || '').trim();
  if (trimmed.length <= MAX_SKILL_SUMMARY_CHARS) return trimmed;
  return `${trimmed.slice(0, MAX_SKILL_SUMMARY_CHARS - 1).trimEnd()}…`;
}

function bound(text) {
  const trimmed = String(text).trim();
  if (trimmed.length <= MAX_PROMPT_CHARS) return trimmed;
  return `${trimmed.slice(0, MAX_PROMPT_CHARS - 15).trimEnd()}... [truncated]`;
}
